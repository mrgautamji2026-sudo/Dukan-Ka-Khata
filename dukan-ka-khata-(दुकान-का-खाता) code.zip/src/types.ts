export type Language = 'en' | 'hi';

export type TransactionType = 'CREDIT_GIVEN' | 'PAYMENT_RECEIVED';

export interface VoiceItemToken {
  name: string;
  quantity: string;
  unit?: string;
  estimatedPrice?: number;
}

export interface Transaction {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  type: TransactionType;
  totalBill: number;
  paidAmount: number;
  remainingDue: number; // calculated: totalBill - paidAmount
  note?: string;
  items?: VoiceItemToken[];
  billImageBase64?: string; // 720p compressed JPG
  voiceNoteAudioBase64?: string; // audio recording blob
  voiceNoteDurationSec?: number;
  createdAt: string; // ISO String
  syncStatus: 'synced' | 'pending';
}

export interface Customer {
  id: string;
  fullName: string;
  primaryMobile: string; // 10 digits
  alternateMobile?: string;
  aadharNumber: string; // 12 digits
  isBlacklisted: boolean; // Red Flag Bad Debt / Blacklist toggle
  totalCreditGiven: number;
  totalPaymentReceived: number;
  netOutstandingBalance: number; // totalCreditGiven - totalPaymentReceived
  initialCreditDate?: string; // For loan duration calculation
  createdAt: string;
  updatedAt: string;
  address?: string;
}

export type UnitType = 'kg' | 'gram' | 'piece' | 'litre' | 'packet';

export interface InventoryItem {
  id: string;
  name: string;
  category: string; // e.g. "Fertilisers (खाद)", "Seeds (बीज)", "Pesticides (कीटनाशक)", "Groceries (किराना)", "Grains (अनाज)"
  pricePerUnit: number;
  unit: UnitType;
  stockQuantity: number;
  lowStockThreshold: number;
  imageBase64?: string;
  voiceTagAudioBase64?: string;
  voiceTagDurationSec?: number;
  updatedAt: string;
}

export type BackupCadence = 'weekly' | 'monthly' | 'yearly';

export interface StoreSettings {
  storeName: string;
  ownerName: string;
  ownerVpa: string; // e.g., mauryakhand@upi
  phone: string;
  address: string;
  merchantEmail: string;
  backupPhone?: string;
  showUpiQrCode: boolean; // Global reactive toggle for QR code visibility
  backupCadence: BackupCadence;
  lastBackupDate?: string;
  googleDriveSynced: boolean;
  lastSyncTimestamp?: string;
}

export interface SyncQueueItem {
  id: string;
  entityType: 'customer' | 'transaction' | 'inventory' | 'settings';
  action: 'create' | 'update' | 'delete';
  payload: any;
  timestamp: string;
  status: 'pending' | 'synced' | 'failed';
}

export interface OutboxNotification {
  id: string;
  customerId: string;
  customerName: string;
  phone: string;
  channel: 'sms' | 'whatsapp';
  senderIdentity: string; // "Maurya Khad Beej Bhandar, Molnapur"
  messageBody: string;
  timestamp: string;
  status: 'sent' | 'queued';
}
