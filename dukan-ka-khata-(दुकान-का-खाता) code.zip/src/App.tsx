import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  Package,
  FileSpreadsheet,
  Settings as SettingsIcon,
  Plus,
  ArrowUpDown,
  Filter,
  CheckCircle,
  FileDown,
  Calendar,
  IndianRupee,
  Clock,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';
import { LanguageProvider, useTranslation } from './context/LanguageContext';
import { db, seedInitialData } from './db/database';
import type { Customer, Transaction, InventoryItem, StoreSettings } from './types';
import { Header } from './components/Header';
import { StatisticsStrip } from './components/StatisticsStrip';
import { VoiceSearchBar } from './components/VoiceSearchBar';
import { CustomerManagement } from './components/CustomerManagement';
import { TransactionModal } from './components/TransactionModal';
import { InventoryLedger } from './components/InventoryLedger';
import { PassbookModal } from './components/PassbookModal';
import { SettingsAndSyncModal } from './components/SettingsAndSyncModal';
import { generateLedgerPDF, downloadPdfBlob } from './services/pdfGenerator';

const DEFAULT_SETTINGS: StoreSettings = {
  storeName: 'Maurya Khad Beej Bhandar, Molnapur',
  ownerName: 'Ramprasad Maurya',
  ownerVpa: 'mauryafertilizer@oksbi',
  phone: '9839012345',
  address: 'Village Molnapur, Post Mohammadabad, Azamgarh, UP - 276403',
  merchantEmail: 'maurya.khad.molnapur@gmail.com',
  backupPhone: '9450123456',
  showUpiQrCode: true,
  backupCadence: 'weekly',
  googleDriveSynced: false,
};

function MainLedgerApp() {
  const { t, language } = useTranslation();

  // Primary Data Collections
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [settings, setSettings] = useState<StoreSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  // Active Navigation Tab
  const [activeMainTab, setActiveMainTab] = useState<'customers' | 'inventory' | 'transactions'>('customers');
  const [customerTabType, setCustomerTabType] = useState<'standard' | 'defaulters'>('standard');

  // Search & Global Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [searchFilterType, setSearchFilterType] = useState<'all' | 'customer' | 'inventory' | 'date'>('all');

  // Modal Dialog States
  const [selectedPassbookCustomer, setSelectedPassbookCustomer] = useState<Customer | null>(null);
  const [activeTxnCustomer, setActiveTxnCustomer] = useState<Customer | null>(null);
  const [forcePaymentOnly, setForcePaymentOnly] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Initial Data Load & Seed from Dexie DB
  const loadDatabaseData = async () => {
    try {
      await seedInitialData();
      const [allCustomers, allTransactions, allInventory, allSettings] = await Promise.all([
        db.customers.toArray(),
        db.transactions.reverse().sortBy('createdAt'),
        db.inventory.toArray(),
        db.settings.get('primary_settings'),
      ]);

      setCustomers(allCustomers);
      setTransactions(allTransactions);
      setInventory(allInventory);
      if (allSettings) {
        setSettings({ ...DEFAULT_SETTINGS, ...allSettings });
      }
    } catch (err) {
      console.error('Error loading ledger data from Dexie:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDatabaseData();
  }, []);

  // Reactive Metric Calculations
  const totalOutstandingDebt = useMemo(() => {
    return customers.reduce((acc, c) => acc + (c.netOutstandingBalance || 0), 0);
  }, [customers]);

  const totalPaidToday = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return transactions
      .filter(t => t.createdAt.startsWith(today) && t.paidAmount > 0)
      .reduce((acc, t) => acc + t.paidAmount, 0);
  }, [transactions]);

  const activeCustomerBase = customers.length;
  const totalInventorySKUs = inventory.length;

  // Global Filtered Customers
  const filteredCustomers = useMemo(() => {
    if (!searchQuery.trim()) return customers;
    const query = searchQuery.toLowerCase().trim();

    return customers.filter(c => {
      const matchName = c.fullName.toLowerCase().includes(query);
      const matchPhone = c.primaryMobile.includes(query) || (c.alternateMobile && c.alternateMobile.includes(query));
      const matchAadhar = c.aadharNumber && c.aadharNumber.replace(/\s+/g, '').includes(query);
      const matchAddress = c.address && c.address.toLowerCase().includes(query);
      return matchName || matchPhone || matchAadhar || matchAddress;
    });
  }, [customers, searchQuery]);

  // Global Filtered Transactions
  const filteredTransactions = useMemo(() => {
    if (!searchQuery.trim()) return transactions;
    const query = searchQuery.toLowerCase().trim();

    return transactions.filter(t => {
      const matchCustomer = t.customerName.toLowerCase().includes(query);
      const matchPhone = t.customerPhone.includes(query);
      const matchDate = t.createdAt.includes(query);
      const matchNote = t.note && t.note.toLowerCase().includes(query);
      const matchItems = t.items && t.items.some(i => i.name.toLowerCase().includes(query));
      return matchCustomer || matchPhone || matchDate || matchNote || matchItems;
    });
  }, [transactions, searchQuery]);

  // Save / Update Customer Handler
  const handleSaveCustomer = async (customerData: Partial<Customer>) => {
    const now = new Date().toISOString();
    if (customerData.id) {
      // Update
      await db.customers.update(customerData.id, {
        ...customerData,
        updatedAt: now,
      });
    } else {
      // Create new
      const newCustomer: Customer = {
        id: `cust-${Date.now()}`,
        fullName: customerData.fullName || '',
        primaryMobile: customerData.primaryMobile || '',
        alternateMobile: customerData.alternateMobile || '',
        aadharNumber: customerData.aadharNumber || '',
        isBlacklisted: customerData.isBlacklisted || false,
        totalCreditGiven: 0,
        totalPaymentReceived: 0,
        netOutstandingBalance: 0,
        createdAt: now,
        updatedAt: now,
        address: customerData.address || '',
      };
      await db.customers.add(newCustomer);
    }
    await loadDatabaseData();
  };

  // Blacklist / Red Flag Toggle Handler
  const handleToggleBlacklist = async (customerId: string, currentState: boolean) => {
    await db.customers.update(customerId, {
      isBlacklisted: !currentState,
      updatedAt: new Date().toISOString(),
    });
    await loadDatabaseData();
  };

  // New Transaction Save Handler
  const handleSaveTransaction = async (
    txnData: Omit<Transaction, 'id' | 'createdAt' | 'syncStatus'>
  ) => {
    const now = new Date().toISOString();
    const newTxn: Transaction = {
      ...txnData,
      id: `txn-${Date.now()}`,
      createdAt: now,
      syncStatus: 'pending',
    };
    await db.transactions.add(newTxn);
    await loadDatabaseData();
  };

  // Update Customer Balance after transaction
  const handleUpdateCustomerBalance = async (
    customerId: string,
    deltaCredit: number,
    deltaPayment: number
  ) => {
    const cust = await db.customers.get(customerId);
    if (!cust) return;

    const newCredit = (cust.totalCreditGiven || 0) + deltaCredit;
    const newPayment = (cust.totalPaymentReceived || 0) + deltaPayment;
    const newNetDue = Math.max(0, newCredit - newPayment);

    await db.customers.update(customerId, {
      totalCreditGiven: newCredit,
      totalPaymentReceived: newPayment,
      netOutstandingBalance: newNetDue,
      initialCreditDate: cust.initialCreditDate || (deltaCredit > 0 ? new Date().toISOString() : undefined),
      updatedAt: new Date().toISOString(),
    });

    await loadDatabaseData();
  };

  // Inventory Save Handler
  const handleSaveInventoryItem = async (itemData: Partial<InventoryItem>) => {
    const now = new Date().toISOString();
    if (itemData.id) {
      await db.inventory.update(itemData.id, {
        ...itemData,
        updatedAt: now,
      });
    } else {
      const newItem: InventoryItem = {
        id: `sku-${Date.now()}`,
        name: itemData.name || '',
        category: itemData.category || 'General',
        pricePerUnit: itemData.pricePerUnit || 0,
        unit: itemData.unit || 'kg',
        stockQuantity: itemData.stockQuantity || 0,
        lowStockThreshold: itemData.lowStockThreshold || 10,
        imageBase64: itemData.imageBase64,
        voiceTagAudioBase64: itemData.voiceTagAudioBase64,
        updatedAt: now,
      };
      await db.inventory.add(newItem);
    }
    await loadDatabaseData();
  };

  // Delete Inventory Item
  const handleDeleteInventoryItem = async (id: string) => {
    if (window.confirm(language === 'hi' ? 'क्या आप इस सामान को हटाना चाहते हैं?' : 'Delete this inventory SKU?')) {
      await db.inventory.delete(id);
      await loadDatabaseData();
    }
  };

  // Update Stock Count
  const handleUpdateStock = async (id: string, newStock: number) => {
    await db.inventory.update(id, {
      stockQuantity: newStock,
      updatedAt: new Date().toISOString(),
    });
    await loadDatabaseData();
  };

  // Save Settings Handler
  const handleSaveSettings = async (newSettings: StoreSettings) => {
    await db.settings.put({ id: 'primary_settings', ...newSettings });
    setSettings(newSettings);
  };

  // Single Customer PDF Export
  const handleExportCustomerPdf = async (customer: Customer) => {
    try {
      const blob = await generateLedgerPDF(settings, [customer], transactions, customer);
      downloadPdfBlob(
        blob,
        `Passbook_${customer.fullName.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.pdf`
      );
    } catch (err) {
      console.error(err);
      alert('Could not generate PDF statement');
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-gray-900 flex flex-col font-sans antialiased selection:bg-[#FF9933] selection:text-white">
      {/* Top Bar Header */}
      <Header onOpenSettings={() => setIsSettingsOpen(true)} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 pt-20 pb-24">
        
        {/* Statistics Strip */}
        <StatisticsStrip
          totalOutstandingDebt={totalOutstandingDebt}
          totalPaidToday={totalPaidToday}
          activeCustomerBase={activeCustomerBase}
          totalInventorySKUs={totalInventorySKUs}
          onFilterDefaulters={() => {
            setActiveMainTab('customers');
            setCustomerTabType('defaulters');
          }}
          onViewCustomers={() => {
            setActiveMainTab('customers');
            setCustomerTabType('standard');
          }}
          onViewInventory={() => {
            setActiveMainTab('inventory');
          }}
        />

        {/* Global Sitewide Voice Search Bar */}
        <VoiceSearchBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          activeFilterType={searchFilterType}
          onFilterTypeChange={type => {
            setSearchFilterType(type);
            if (type === 'inventory') setActiveMainTab('inventory');
            if (type === 'customer') setActiveMainTab('customers');
          }}
        />

        {/* Main Navigation Segmented Tabs */}
        <div className="flex items-center justify-between gap-2 my-4 border-b border-gray-200 pb-2">
          <div className="flex items-center gap-2">
            <button
              id="main-nav-tab-customers"
              onClick={() => setActiveMainTab('customers')}
              className={`flex items-center gap-1.5 px-3.5 sm:px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition shadow-xs ${
                activeMainTab === 'customers'
                  ? 'bg-[#000080] text-white shadow-md'
                  : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              <Users className="w-4 h-4 text-amber-300" />
              {t('customersTab')} ({customers.length})
            </button>

            <button
              id="main-nav-tab-inventory"
              onClick={() => setActiveMainTab('inventory')}
              className={`flex items-center gap-1.5 px-3.5 sm:px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition shadow-xs ${
                activeMainTab === 'inventory'
                  ? 'bg-[#000080] text-white shadow-md'
                  : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              <Package className="w-4 h-4 text-[#FF9933]" />
              {t('inventoryTab')} ({inventory.length})
            </button>

            <button
              id="main-nav-tab-transactions"
              onClick={() => setActiveMainTab('transactions')}
              className={`flex items-center gap-1.5 px-3.5 sm:px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition shadow-xs ${
                activeMainTab === 'transactions'
                  ? 'bg-[#000080] text-white shadow-md'
                  : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4 text-[#138808]" />
              {t('transactionsTab')} ({transactions.length})
            </button>
          </div>

          <button
            onClick={() => setIsSettingsOpen(true)}
            className="flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 bg-white hover:bg-gray-100 text-gray-700 rounded-xl border border-gray-200 text-xs font-bold transition shadow-2xs"
            title={t('settingsTitle')}
          >
            <SettingsIcon className="w-4 h-4 text-gray-500" />
            <span className="hidden sm:inline">{t('settingsTitle')}</span>
          </button>
        </div>

        {/* View 1: Customers & Credit Engine */}
        {activeMainTab === 'customers' && (
          <CustomerManagement
            customers={filteredCustomers}
            transactions={transactions}
            activeTab={customerTabType}
            onTabChange={setCustomerTabType}
            onSelectCustomer={cust => setSelectedPassbookCustomer(cust)}
            onOpenNewTransaction={(cust, onlyPay) => {
              setActiveTxnCustomer(cust);
              setForcePaymentOnly(!!onlyPay);
            }}
            onSaveCustomer={handleSaveCustomer}
            onToggleBlacklist={handleToggleBlacklist}
            onExportCustomerPdf={handleExportCustomerPdf}
          />
        )}

        {/* View 2: Inventory Ledger Matrix */}
        {activeMainTab === 'inventory' && (
          <InventoryLedger
            items={inventory}
            onSaveItem={handleSaveInventoryItem}
            onDeleteItem={handleDeleteInventoryItem}
            onUpdateStock={handleUpdateStock}
          />
        )}

        {/* View 3: Transactions Journal */}
        {activeMainTab === 'transactions' && (
          <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-gray-100">
              <div>
                <h3 className="font-bold text-base text-gray-900 flex items-center gap-2 font-hindi-heading">
                  <FileSpreadsheet className="w-5 h-5 text-[#138808]" />
                  {t('transactionsTab')}
                </h3>
                <p className="text-xs text-gray-500">
                  {language === 'hi'
                    ? 'दुकान में हुए सभी उधार एवं जमा लेन-देन का ब्यौरा'
                    : 'Consolidated audit trail of all credit issued and payments received'}
                </p>
              </div>

              <div className="text-xs font-mono text-gray-500 bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-200">
                Total: {filteredTransactions.length} entries
              </div>
            </div>

            {filteredTransactions.length === 0 ? (
              <div className="py-12 text-center text-gray-400 text-xs font-medium">
                No transactions recorded yet.
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {filteredTransactions.map(txn => {
                  const dateStr = new Date(txn.createdAt).toLocaleDateString(
                    language === 'hi' ? 'hi-IN' : 'en-IN',
                    {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    }
                  );

                  return (
                    <div
                      key={txn.id}
                      className="py-3 sm:py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-gray-50/80 px-2 rounded-xl transition"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                              txn.type === 'CREDIT_GIVEN'
                                ? 'bg-amber-100 text-[#FF9933]'
                                : 'bg-emerald-100 text-[#138808]'
                            }`}
                          >
                            {txn.type === 'CREDIT_GIVEN'
                              ? language === 'hi'
                                ? 'उधार'
                                : 'Credit'
                              : language === 'hi'
                              ? 'जमा'
                              : 'Payment'}
                          </span>
                          <span className="font-bold text-sm text-gray-900">
                            {txn.customerName}
                          </span>
                          <span className="text-xs font-mono text-gray-400">
                            +91 {txn.customerPhone}
                          </span>
                        </div>

                        <p className="text-xs text-gray-600">
                          {txn.note || (txn.items?.map(i => `${i.name} (${i.quantity})`).join(', ') || '-')}
                        </p>

                        <span className="text-[11px] text-gray-400 font-mono flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {dateStr}
                        </span>
                      </div>

                      <div className="text-right sm:border-l sm:border-gray-100 sm:pl-4 shrink-0">
                        <div className="text-xs text-gray-400">
                          Bill: ₹{txn.totalBill.toLocaleString('en-IN')} | Paid: ₹
                          {txn.paidAmount.toLocaleString('en-IN')}
                        </div>
                        <div
                          className={`text-base font-black font-mono mt-0.5 ${
                            txn.remainingDue > 0 ? 'text-red-600' : 'text-[#138808]'
                          }`}
                        >
                          Due: ₹{txn.remainingDue.toLocaleString('en-IN')}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Customer Passbook Modal */}
      {selectedPassbookCustomer && (
        <PassbookModal
          isOpen={!!selectedPassbookCustomer}
          onClose={() => setSelectedPassbookCustomer(null)}
          customer={selectedPassbookCustomer}
          transactions={transactions}
          storeSettings={settings}
          onNewTransaction={cust => {
            setSelectedPassbookCustomer(null);
            setActiveTxnCustomer(cust);
            setForcePaymentOnly(false);
          }}
          onExportPdf={handleExportCustomerPdf}
        />
      )}

      {/* Transaction Modal (Calculator pad, Camera, Voice, Dynamic UPI QR) */}
      {activeTxnCustomer && (
        <TransactionModal
          isOpen={!!activeTxnCustomer}
          onClose={() => {
            setActiveTxnCustomer(null);
            setForcePaymentOnly(false);
          }}
          customer={activeTxnCustomer}
          storeSettings={settings}
          forcePaymentOnly={forcePaymentOnly}
          onSaveTransaction={handleSaveTransaction}
          onUpdateCustomerBalance={handleUpdateCustomerBalance}
        />
      )}

      {/* Global Ledger Settings & Backup Management Modal */}
      {isSettingsOpen && (
        <SettingsAndSyncModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          settings={settings}
          customers={customers}
          transactions={transactions}
          inventory={inventory}
          onSaveSettings={handleSaveSettings}
          onRefreshData={loadDatabaseData}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <MainLedgerApp />
    </LanguageProvider>
  );
}
