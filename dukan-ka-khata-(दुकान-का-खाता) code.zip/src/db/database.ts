import Dexie, { type Table } from 'dexie';
import type { Customer, Transaction, InventoryItem, SyncQueueItem, StoreSettings, OutboxNotification } from '../types';

export class DukanKaKhataDB extends Dexie {
  customers!: Table<Customer, string>;
  transactions!: Table<Transaction, string>;
  inventory!: Table<InventoryItem, string>;
  syncQueue!: Table<SyncQueueItem, string>;
  settings!: Table<StoreSettings & { id: string }, string>;
  outbox!: Table<OutboxNotification, string>;

  constructor() {
    super('DukanKaKhataDatabase');
    this.version(1).stores({
      customers: 'id, fullName, primaryMobile, aadharNumber, isBlacklisted, netOutstandingBalance, updatedAt',
      transactions: 'id, customerId, customerPhone, type, createdAt, syncStatus',
      inventory: 'id, name, category, unit, stockQuantity, updatedAt',
      syncQueue: 'id, entityType, timestamp, status',
      settings: 'id',
      outbox: 'id, customerId, timestamp, status',
    });
  }
}

export const db = new DukanKaKhataDB();

export const DEFAULT_STORE_SETTINGS: StoreSettings = {
  storeName: 'Maurya Khad Beej Bhandar, Molnapur',
  ownerName: 'Ramprasad Maurya',
  ownerVpa: 'mauryafertilizer@oksbi',
  phone: '+91 98391 23456',
  address: 'Main Bazaar, Molnapur, District Azamgarh, Uttar Pradesh - 276001',
  merchantEmail: 'maurya.khadbeej@gmail.com',
  showUpiQrCode: true,
  backupCadence: 'weekly',
  googleDriveSynced: false,
  lastSyncTimestamp: new Date().toISOString(),
};

// Seed initial realistic data for Indian micro-merchant
export async function seedInitialDatabaseIfEmpty(): Promise<void> {
  const customerCount = await db.customers.count();
  if (customerCount > 0) return;

  // 1. Initial Store Settings
  await db.settings.put({ id: 'primary_settings', ...DEFAULT_STORE_SETTINGS });

  // 2. Initial Customers
  const initialCustomers: Customer[] = [
    {
      id: 'cust-1',
      fullName: 'Rameshwar Singh Yadav',
      primaryMobile: '9838012345',
      alternateMobile: '9450123456',
      aadharNumber: '5421 8974 1230',
      isBlacklisted: true, // Marked as defaulter/blacklist warning
      totalCreditGiven: 48500,
      totalPaymentReceived: 12000,
      netOutstandingBalance: 36500,
      initialCreditDate: '2026-06-15T10:30:00.000Z',
      createdAt: '2026-06-15T10:30:00.000Z',
      updatedAt: '2026-09-12T11:20:00.000Z',
      address: 'Village Molnapur Tola, Azamgarh',
    },
    {
      id: 'cust-2',
      fullName: 'Santosh Kumar Maurya',
      primaryMobile: '8765432109',
      alternateMobile: '7398124567',
      aadharNumber: '7890 1234 5678',
      isBlacklisted: false,
      totalCreditGiven: 28400,
      totalPaymentReceived: 18000,
      netOutstandingBalance: 10400,
      initialCreditDate: '2026-07-20T09:15:00.000Z',
      createdAt: '2026-07-20T09:15:00.000Z',
      updatedAt: '2026-09-15T14:40:00.000Z',
      address: 'Chauraha Molnapur, Ward 4',
    },
    {
      id: 'cust-3',
      fullName: 'Harish Chandra Tiwari',
      primaryMobile: '9123456780',
      alternateMobile: '',
      aadharNumber: '6543 2109 8765',
      isBlacklisted: false,
      totalCreditGiven: 14200,
      totalPaymentReceived: 14200,
      netOutstandingBalance: 0,
      initialCreditDate: '2026-08-05T12:00:00.000Z',
      createdAt: '2026-08-05T12:00:00.000Z',
      updatedAt: '2026-09-18T16:10:00.000Z',
      address: 'Brahmin Tola, Molnapur',
    },
    {
      id: 'cust-4',
      fullName: 'Mohammad Shamim Ansari',
      primaryMobile: '9935123987',
      alternateMobile: '8874112233',
      aadharNumber: '9876 5432 1098',
      isBlacklisted: true, // Top Defaulter
      totalCreditGiven: 56000,
      totalPaymentReceived: 14000,
      netOutstandingBalance: 42000,
      initialCreditDate: '2026-05-10T08:00:00.000Z',
      createdAt: '2026-05-10T08:00:00.000Z',
      updatedAt: '2026-09-10T10:00:00.000Z',
      address: 'Near Old Madarsa, Molnapur',
    },
    {
      id: 'cust-5',
      fullName: 'Brijesh Prajapati',
      primaryMobile: '7080123901',
      alternateMobile: '',
      aadharNumber: '3210 9876 5432',
      isBlacklisted: false,
      totalCreditGiven: 9500,
      totalPaymentReceived: 3500,
      netOutstandingBalance: 6000,
      initialCreditDate: '2026-08-25T11:45:00.000Z',
      createdAt: '2026-08-25T11:45:00.000Z',
      updatedAt: '2026-09-17T09:30:00.000Z',
      address: 'Kohar Basti, Molnapur',
    },
  ];

  await db.customers.bulkPut(initialCustomers);

  // 3. Initial Transactions
  const initialTransactions: Transaction[] = [
    {
      id: 'txn-1',
      customerId: 'cust-1',
      customerName: 'Rameshwar Singh Yadav',
      customerPhone: '9838012345',
      type: 'CREDIT_GIVEN',
      totalBill: 18500,
      paidAmount: 5000,
      remainingDue: 13500,
      note: 'DAP Fertilizer 5 bags + Hybrid Paddy Seeds 2 packets',
      items: [
        { name: 'DAP Fertilizer (खाद)', quantity: '5 bag' },
        { name: 'Hybrid Paddy Seeds (धान बीज)', quantity: '2 pkt' },
      ],
      createdAt: '2026-06-15T10:30:00.000Z',
      syncStatus: 'synced',
    },
    {
      id: 'txn-2',
      customerId: 'cust-1',
      customerName: 'Rameshwar Singh Yadav',
      customerPhone: '9838012345',
      type: 'CREDIT_GIVEN',
      totalBill: 30000,
      paidAmount: 7000,
      remainingDue: 23000,
      note: 'Urea Fertilizer 15 bags + Insecticide Spray',
      items: [
        { name: 'Urea (नीम कोटेड यूरिया)', quantity: '15 bag' },
        { name: 'Coragen Spray', quantity: '2 bot' },
      ],
      createdAt: '2026-08-01T15:20:00.000Z',
      syncStatus: 'synced',
    },
    {
      id: 'txn-3',
      customerId: 'cust-2',
      customerName: 'Santosh Kumar Maurya',
      customerPhone: '8765432109',
      type: 'CREDIT_GIVEN',
      totalBill: 28400,
      paidAmount: 8000,
      remainingDue: 20400,
      note: 'Wheat Seeds + Super Phosphate 4 bags',
      createdAt: '2026-07-20T09:15:00.000Z',
      syncStatus: 'synced',
    },
    {
      id: 'txn-4',
      customerId: 'cust-2',
      customerName: 'Santosh Kumar Maurya',
      customerPhone: '8765432109',
      type: 'PAYMENT_RECEIVED',
      totalBill: 10000,
      paidAmount: 10000,
      remainingDue: 0,
      note: 'Cash payment received via harvest advance',
      createdAt: new Date().toISOString(), // today payment
      syncStatus: 'synced',
    },
    {
      id: 'txn-5',
      customerId: 'cust-4',
      customerName: 'Mohammad Shamim Ansari',
      customerPhone: '9935123987',
      type: 'CREDIT_GIVEN',
      totalBill: 56000,
      paidAmount: 14000,
      remainingDue: 42000,
      note: 'Potash 10 bags + Zinc Sulphate + Mustard seeds',
      createdAt: '2026-05-10T08:00:00.000Z',
      syncStatus: 'synced',
    },
    {
      id: 'txn-6',
      customerId: 'cust-3',
      customerName: 'Harish Chandra Tiwari',
      customerPhone: '9123456780',
      type: 'PAYMENT_RECEIVED',
      totalBill: 14200,
      paidAmount: 14200,
      remainingDue: 0,
      note: 'Full settlement of vegetable seeds and spray',
      createdAt: new Date().toISOString(), // today payment
      syncStatus: 'synced',
    },
  ];

  await db.transactions.bulkPut(initialTransactions);

  // 4. Initial Inventory SKUs ("Dukan Stock Ledger")
  const initialInventory: InventoryItem[] = [
    {
      id: 'sku-1',
      name: 'IFFCO Neem Coated Urea (यूरिया)',
      category: 'Fertilisers (खाद)',
      pricePerUnit: 267,
      unit: 'packet',
      stockQuantity: 185,
      lowStockThreshold: 30,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'sku-2',
      name: 'DAP 18:46:0 Fertilizer (डी.ए.पी. खाद)',
      category: 'Fertilisers (खाद)',
      pricePerUnit: 1350,
      unit: 'packet',
      stockQuantity: 42,
      lowStockThreshold: 20,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'sku-3',
      name: 'MOP Potash Fertilizer (पोटाश)',
      category: 'Fertilisers (खाद)',
      pricePerUnit: 1700,
      unit: 'packet',
      stockQuantity: 18,
      lowStockThreshold: 15,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'sku-4',
      name: 'Pioneer Hybrid Mustard Seed 45S46 (सरसों बीज)',
      category: 'Seeds (बीज)',
      pricePerUnit: 980,
      unit: 'kg',
      stockQuantity: 65,
      lowStockThreshold: 10,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'sku-5',
      name: 'Shriram Shreshtha Wheat Seeds (गेहूं बीज)',
      category: 'Seeds (बीज)',
      pricePerUnit: 42,
      unit: 'kg',
      stockQuantity: 480,
      lowStockThreshold: 100,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'sku-6',
      name: 'Chlorpyrifos 50% + Cypermethrin 5% EC (कीटनाशक)',
      category: 'Pesticides (कीटनाशक)',
      pricePerUnit: 650,
      unit: 'litre',
      stockQuantity: 28,
      lowStockThreshold: 10,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'sku-7',
      name: 'Pure Mustard Oil Kacchi Ghani (सरसों का तेल)',
      category: 'Groceries (किराना)',
      pricePerUnit: 145,
      unit: 'litre',
      stockQuantity: 84,
      lowStockThreshold: 15,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'sku-8',
      name: 'Refined Sugar Madhur (शुद्ध चीनी)',
      category: 'Groceries (किराना)',
      pricePerUnit: 44,
      unit: 'kg',
      stockQuantity: 320,
      lowStockThreshold: 50,
      updatedAt: new Date().toISOString(),
    },
  ];

  await db.inventory.bulkPut(initialInventory);
}

export const seedInitialData = seedInitialDatabaseIfEmpty;

/**
 * Exports entire IndexedDB state to a serialized JSON string for backup
 */
export async function exportAllDataAsJson(): Promise<string> {
  const [customers, transactions, inventory, settings, outbox] = await Promise.all([
    db.customers.toArray(),
    db.transactions.toArray(),
    db.inventory.toArray(),
    db.settings.toArray(),
    db.outbox.toArray(),
  ]);

  const backupPayload = {
    app: 'Dukan Ka Khata',
    version: 1,
    exportedAt: new Date().toISOString(),
    data: {
      customers,
      transactions,
      inventory,
      settings,
      outbox,
    },
  };

  return JSON.stringify(backupPayload, null, 2);
}

/**
 * Imports state from backup JSON string into IndexedDB
 */
export async function importDataFromJson(jsonString: string): Promise<void> {
  const parsed = JSON.parse(jsonString);
  if (!parsed || !parsed.data) {
    throw new Error('Invalid backup format');
  }

  const { customers, transactions, inventory, settings, outbox } = parsed.data;

  if (Array.isArray(customers) && customers.length > 0) {
    await db.customers.clear();
    await db.customers.bulkPut(customers);
  }

  if (Array.isArray(transactions) && transactions.length > 0) {
    await db.transactions.clear();
    await db.transactions.bulkPut(transactions);
  }

  if (Array.isArray(inventory) && inventory.length > 0) {
    await db.inventory.clear();
    await db.inventory.bulkPut(inventory);
  }

  if (Array.isArray(settings) && settings.length > 0) {
    await db.settings.clear();
    await db.settings.bulkPut(settings);
  }

  if (Array.isArray(outbox) && outbox.length > 0) {
    await db.outbox.clear();
    await db.outbox.bulkPut(outbox);
  }
}
