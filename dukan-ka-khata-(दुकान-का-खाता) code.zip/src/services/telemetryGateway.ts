import { db } from '../db/database';
import type { Customer, Transaction, OutboxNotification, Language } from '../types';

export const SENDER_IDENTITY = 'Maurya Khad Beej Bhandar, Molnapur';

/**
 * Computes days elapsed since initial credit date or transaction date.
 */
export function calculateDaysElapsed(fromDateStr?: string): number {
  if (!fromDateStr) return 0;
  const start = new Date(fromDateStr).getTime();
  const now = new Date().getTime();
  const diffMs = Math.max(0, now - start);
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Builds the notification payload according to the strict customer perspective blueprint:
 * - Action Date/Time
 * - Amount Borrowed / Paid
 * - Current Balance
 * - Computed duration: "Loan Balance borrowed on: [Date]. Total days elapsed: [X Days] from date of initial credit request."
 * - Thank-you token: "Thank you for shopping at Maurya Khad Beej Bhandar! / मौर्य खाद बीज भंडार में खरीदारी के लिए आपका धन्यवाद!"
 */
export function buildNotificationPayload(
  customer: Customer,
  transaction: Transaction,
  lang: Language = 'hi'
): string {
  const dateFormatted = new Date(transaction.createdAt).toLocaleString(
    lang === 'hi' ? 'hi-IN' : 'en-IN',
    {
      dateStyle: 'medium',
      timeStyle: 'short',
    }
  );

  const initialDateFormatted = customer.initialCreditDate
    ? new Date(customer.initialCreditDate).toLocaleDateString(
        lang === 'hi' ? 'hi-IN' : 'en-IN'
      )
    : dateFormatted;

  const daysElapsed = calculateDaysElapsed(customer.initialCreditDate || transaction.createdAt);

  if (lang === 'hi') {
    const actionTypeStr =
      transaction.type === 'CREDIT_GIVEN' ? 'उधार दर्ज हुआ' : 'जमा भुगतान प्राप्त हुआ';
    
    return [
      `🏛️ *${SENDER_IDENTITY}*`,
      `नमस्ते *${customer.fullName}* जी,`,
      `आपके खाते में नया विवरण:`,
      `📅 दिनांक व समय: ${dateFormatted}`,
      `📌 प्रकार: ${actionTypeStr}`,
      `💰 कुल बिल: ₹${transaction.totalBill.toLocaleString('en-IN')}`,
      `💵 जमा राशि: ₹${transaction.paidAmount.toLocaleString('en-IN')}`,
      `⚖️ वर्तमान शेष बकाया: ₹${customer.netOutstandingBalance.toLocaleString('en-IN')}`,
      ``,
      `⏳ *ऋण अवधि ट्रैकिंग:*`,
      `उधार खाता प्रारंभ तिथि: ${initialDateFormatted}। उधार लिए कुल *${daysElapsed} दिन* बीत चुके हैं।`,
      ``,
      `🙏 *मौर्य खाद बीज भंडार में खरीदारी के लिए आपका धन्यवाद!*`,
      `📞 संपर्क: +91 98391 23456 | मुख्य बाज़ार, मोलनापुर`
    ].join('\n');
  }

  const actionTypeStr =
    transaction.type === 'CREDIT_GIVEN' ? 'Credit Issued (Udhar)' : 'Payment Received (Jama)';

  return [
    `🏛️ *${SENDER_IDENTITY}*`,
    `Dear *${customer.fullName}*,`,
    `A new transaction has been logged in your account:`,
    `📅 Date & Time: ${dateFormatted}`,
    `📌 Type: ${actionTypeStr}`,
    `💰 Total Bill: ₹${transaction.totalBill.toLocaleString('en-IN')}`,
    `💵 Paid Amount: ₹${transaction.paidAmount.toLocaleString('en-IN')}`,
    `⚖️ Current Outstanding Balance: ₹${customer.netOutstandingBalance.toLocaleString('en-IN')}`,
    ``,
    `⏳ *Credit Duration Tracking:*`,
    `Loan Balance borrowed on: ${initialDateFormatted}. Total days elapsed: *${daysElapsed} Days* from date of initial credit request.`,
    ``,
    `🙏 *Thank you for shopping at Maurya Khad Beej Bhandar!*`,
    `📞 Contact: +91 98391 23456 | Main Bazaar, Molnapur`
  ].join('\n');
}

/**
 * Dispatches simulated background cloud function targeting SMS Gateway & WhatsApp Business API,
 * and creates ready-to-launch links.
 */
export async function dispatchTransactionalCommunication(
  customer: Customer,
  transaction: Transaction,
  lang: Language = 'hi'
): Promise<{
  outboxItem: OutboxNotification;
  whatsappUrl: string;
  smsUrl: string;
}> {
  const messageBody = buildNotificationPayload(customer, transaction, lang);
  const cleanPhone = customer.primaryMobile.replace(/\D/g, '');
  const internationalPhone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;

  const outboxItem: OutboxNotification = {
    id: `outbox-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    customerId: customer.id,
    customerName: customer.fullName,
    phone: customer.primaryMobile,
    channel: 'whatsapp',
    senderIdentity: SENDER_IDENTITY,
    messageBody,
    timestamp: new Date().toISOString(),
    status: 'sent',
  };

  await db.outbox.put(outboxItem);

  const whatsappUrl = `https://api.whatsapp.com/send?phone=${internationalPhone}&text=${encodeURIComponent(
    messageBody
  )}`;
  const smsUrl = `sms:${cleanPhone}?body=${encodeURIComponent(messageBody)}`;

  return { outboxItem, whatsappUrl, smsUrl };
}
