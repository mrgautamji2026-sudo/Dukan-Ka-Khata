import type { VoiceItemToken } from '../types';

// Hindi number mappings to numeric strings
const HINDI_NUMBER_MAP: Record<string, string> = {
  'एक': '1',
  'दो': '2',
  'तीन': '3',
  'चार': '4',
  'पाँच': '5',
  'पांच': '5',
  'छह': '6',
  'छः': '6',
  'सात': '7',
  'आठ': '8',
  'नौ': '9',
  'दस': '10',
  'ग्यारह': '11',
  'बारह': '12',
  'पंद्रह': '15',
  'बीस': '20',
  'पच्चीस': '25',
  'तीस': '30',
  'चालीस': '40',
  'पचास': '50',
  'सौ': '100',
  'आधा': '0.5',
  'डेढ़': '1.5',
  'ढाई': '2.5',
};

const UNIT_MAP: Record<string, string> = {
  'किलो': 'kg',
  'किलोग्राम': 'kg',
  'kg': 'kg',
  'kgs': 'kg',
  'kilo': 'kg',
  'ग्राम': 'gram',
  'gm': 'gram',
  'gram': 'gram',
  'लीटर': 'L',
  'लिटर': 'L',
  'litre': 'L',
  'liter': 'L',
  'l': 'L',
  'पैकेट': 'pkt',
  'पैकिट': 'pkt',
  'packet': 'pkt',
  'pkt': 'pkt',
  'बोरी': 'bag',
  'बैग': 'bag',
  'कट्टा': 'bag',
  'bag': 'bag',
  'पीस': 'pc',
  'नग': 'pc',
  'piece': 'pc',
  'pc': 'pc',
  'बोतल': 'bottle',
  'bottle': 'bottle',
};

/**
 * Parses dictated Hindi/English voice string into structured item tokens.
 * Example 1: "दो किलो चीनी पांच लीटर तेल" -> [{ name: "चीनी", quantity: "2 kg" }, { name: "तेल", quantity: "5 L" }]
 * Example 2: "10 bag urea 2 bottle coragen" -> [{ name: "urea", quantity: "10 bag" }, { name: "coragen", quantity: "2 bottle" }]
 */
export function tokenizeVoiceDictation(text: string): VoiceItemToken[] {
  if (!text || !text.trim()) return [];

  // Normalize string
  let cleaned = text.toLowerCase().trim();

  // Replace Hindi number words with digits where followed by unit or item
  for (const [hindiNum, digit] of Object.entries(HINDI_NUMBER_MAP)) {
    const regex = new RegExp(`\\b${hindiNum}\\b`, 'gi');
    cleaned = cleaned.replace(regex, digit);
  }

  // Regex pattern matching: [quantity] [unit?] [item name] or [item name] [quantity] [unit?]
  // Matches "2 किलो चीनी" or "2 kg sugar" or "5 bag DAP"
  const tokens: VoiceItemToken[] = [];

  // Split by conjunctions like "और", "and", comma, or plus
  const parts = cleaned.split(/[\n,;]|(?:\s+और\s+) |(?:\s+and\s+)/i);

  for (const part of parts) {
    const trimmed = part.trim();
    if (!trimmed) continue;

    // Pattern A: Number + Unit + Item Name (e.g., "2 किलो चीनी", "5 ltr mustard oil", "10 bag DAP")
    const matchA = trimmed.match(/^(\d+(?:\.\d+)?)\s*([a-zA-Z\u0900-\u097F]+)?\s+(.+)$/);
    if (matchA) {
      const rawQty = matchA[1];
      const rawUnit = matchA[2]?.toLowerCase() || '';
      const rawName = matchA[3]?.trim();

      const mappedUnit = UNIT_MAP[rawUnit] || rawUnit;
      tokens.push({
        name: capitalizeFirst(rawName),
        quantity: `${rawQty} ${mappedUnit}`.trim(),
        unit: mappedUnit,
      });
      continue;
    }

    // Pattern B: Item Name + Number + Unit (e.g., "चीनी 2 किलो", "Urea 5 bag")
    const matchB = trimmed.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s*([a-zA-Z\u0900-\u097F]*)$/);
    if (matchB) {
      const rawName = matchB[1]?.trim();
      const rawQty = matchB[2];
      const rawUnit = matchB[3]?.toLowerCase() || '';

      const mappedUnit = UNIT_MAP[rawUnit] || rawUnit;
      tokens.push({
        name: capitalizeFirst(rawName),
        quantity: `${rawQty} ${mappedUnit}`.trim(),
        unit: mappedUnit,
      });
      continue;
    }

    // Fallback: simple item without explicit quantity
    tokens.push({
      name: capitalizeFirst(trimmed),
      quantity: '1 unit',
    });
  }

  return tokens;
}

function capitalizeFirst(str: string): string {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// Browser Web Speech API helper
export interface SpeechRecognitionHookResult {
  isListening: boolean;
  transcript: string;
  startListening: (lang?: 'hi-IN' | 'en-IN') => void;
  stopListening: () => void;
  isSupported: boolean;
}

export function createSpeechRecognizer(
  onResult: (transcript: string) => void,
  onError?: (err: any) => void
) {
  const SpeechRecognition =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) {
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.maxAlternatives = 1;

  recognition.onresult = (event: any) => {
    let current = '';
    for (let i = event.resultIndex; i < event.results.length; ++i) {
      current += event.results[i][0].transcript;
    }
    onResult(current);
  };

  if (onError) {
    recognition.onerror = onError;
  }

  return recognition;
}
