import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { Customer, Transaction, StoreSettings } from '../types';
import { SENDER_IDENTITY, calculateDaysElapsed } from './telemetryGateway';

/**
 * Generates client-side multi-page PDF ledger statement.
 */
export async function generateLedgerPDF(
  settings: StoreSettings,
  customers: Customer[],
  transactions: Transaction[],
  selectedCustomer?: Customer
): Promise<Blob> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // Helper to draw Tricolour Header Band
  const drawHeader = (pageNumber: number, totalPages: number) => {
    // Saffron top band
    doc.setFillColor(255, 153, 51);
    doc.rect(0, 0, pageWidth, 8, 'F');

    // Navy blue micro-line
    doc.setFillColor(0, 0, 128);
    doc.rect(0, 8, pageWidth, 1.5, 'F');

    // Title area
    doc.setTextColor(0, 0, 128);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text(settings.storeName || SENDER_IDENTITY, pageWidth / 2, 17, { align: 'center' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(75, 85, 99);
    doc.text(
      `${settings.address} | Phone: ${settings.phone} | Prop: ${settings.ownerName}`,
      pageWidth / 2,
      22,
      { align: 'center' }
    );

    // Green divider line
    doc.setDrawColor(19, 136, 8);
    doc.setLineWidth(0.8);
    doc.line(14, 25, pageWidth - 14, 25);

    // Page number bottom
    doc.setFontSize(8);
    doc.setTextColor(156, 163, 175);
    doc.text(
      `Dukan Ka Khata Digital Ledger - Page ${pageNumber} of ${totalPages}`,
      pageWidth / 2,
      pageHeight - 6,
      { align: 'center' }
    );
  };

  // Title section
  const reportDate = new Date().toLocaleDateString('en-IN', {
    dateStyle: 'full',
  });

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 128);
  const docTitle = selectedCustomer
    ? `CUSTOMER KHATA PASSBOOK: ${selectedCustomer.fullName.toUpperCase()}`
    : 'CONSOLIDATED MASTER LEDGER STATEMENT';
  doc.text(docTitle, 14, 33);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text(`Generated on: ${reportDate} | UPI VPA: ${settings.ownerVpa}`, 14, 38);

  let currentY = 44;

  if (selectedCustomer) {
    // Individual Customer Summary Card
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(14, currentY, pageWidth - 28, 26, 3, 3, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text(`Account Holder: ${selectedCustomer.fullName}`, 18, currentY + 6);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(`Mobile: ${selectedCustomer.primaryMobile} ${selectedCustomer.alternateMobile ? `| Alt: ${selectedCustomer.alternateMobile}` : ''}`, 18, currentY + 12);
    doc.text(`Aadhar: ${selectedCustomer.aadharNumber || 'N/A'} | Location: ${selectedCustomer.address || 'Molnapur'}`, 18, currentY + 18);

    // Stats badge inside card
    const daysElapsed = calculateDaysElapsed(selectedCustomer.initialCreditDate || selectedCustomer.createdAt);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(selectedCustomer.netOutstandingBalance > 0 ? 185 : 19, selectedCustomer.netOutstandingBalance > 0 ? 28 : 136, selectedCustomer.netOutstandingBalance > 0 ? 28 : 8);
    doc.text(`Outstanding Balance: Rs. ${selectedCustomer.netOutstandingBalance.toLocaleString('en-IN')}`, 18, currentY + 23);
    doc.setTextColor(100, 116, 139);
    doc.setFont('helvetica', 'normal');
    doc.text(`(Duration: ${daysElapsed} days elapsed since initial credit)`, 95, currentY + 23);

    currentY += 32;

    // Customer specific transactions table
    const custTxns = transactions.filter(t => t.customerId === selectedCustomer.id);
    const tableData = custTxns.map(t => [
      new Date(t.createdAt).toLocaleDateString('en-IN'),
      t.type === 'CREDIT_GIVEN' ? 'CREDIT (UDHAR)' : 'PAYMENT (JAMA)',
      t.note || (t.items?.map(i => `${i.name} (${i.quantity})`).join(', ') || '-'),
      `Rs. ${t.totalBill.toLocaleString('en-IN')}`,
      `Rs. ${t.paidAmount.toLocaleString('en-IN')}`,
      `Rs. ${t.remainingDue.toLocaleString('en-IN')}`,
    ]);

    autoTable(doc, {
      startY: currentY,
      head: [['Date', 'Type', 'Description / Items', 'Total Bill', 'Paid Amount', 'Remaining Due']],
      body: tableData.length > 0 ? tableData : [['-', '-', 'No transactions recorded yet', '-', '-', '-']],
      theme: 'grid',
      headStyles: {
        fillColor: [0, 0, 128],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 9,
      },
      styles: {
        fontSize: 8.5,
        cellPadding: 2.5,
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },
      margin: { left: 14, right: 14 },
    });
  } else {
    // Consolidated Customers Overview Table
    const totalOutstanding = customers.reduce((sum, c) => sum + c.netOutstandingBalance, 0);
    const totalGiven = customers.reduce((sum, c) => sum + c.totalCreditGiven, 0);
    const totalReceived = customers.reduce((sum, c) => sum + c.totalPaymentReceived, 0);

    // Summary Metrics Banner
    doc.setFillColor(254, 243, 199);
    doc.setDrawColor(245, 158, 11);
    doc.roundedRect(14, currentY, pageWidth - 28, 18, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(180, 83, 9);
    doc.text('MASTER LEDGER METRICS TOTALS:', 18, currentY + 6);
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'normal');
    doc.text(
      `Total Credit Disbursed: Rs. ${totalGiven.toLocaleString('en-IN')}  |  Total Collected: Rs. ${totalReceived.toLocaleString('en-IN')}  |  Net Due: Rs. ${totalOutstanding.toLocaleString('en-IN')}`,
      18,
      currentY + 12
    );

    currentY += 24;

    const tableRows = customers.map(c => [
      c.fullName,
      c.primaryMobile,
      c.aadharNumber || 'N/A',
      c.isBlacklisted ? 'BLACKLISTED' : 'ACTIVE',
      `Rs. ${c.totalCreditGiven.toLocaleString('en-IN')}`,
      `Rs. ${c.totalPaymentReceived.toLocaleString('en-IN')}`,
      `Rs. ${c.netOutstandingBalance.toLocaleString('en-IN')}`,
    ]);

    autoTable(doc, {
      startY: currentY,
      head: [['Customer Name', 'Mobile', 'Aadhar No.', 'Status', 'Total Credit', 'Total Paid', 'Balance Due']],
      body: tableRows,
      theme: 'grid',
      headStyles: {
        fillColor: [0, 0, 128],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 8.5,
      },
      styles: {
        fontSize: 8,
        cellPadding: 2,
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },
      margin: { left: 14, right: 14 },
    });
  }

  // Get final Y from autoTable
  const finalY = (doc as any).lastAutoTable?.finalY || 150;
  const signatureY = Math.min(finalY + 25, pageHeight - 35);

  // Business Signature and Stamp
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.5);

  // Merchant Authorized Signature Box
  doc.rect(pageWidth - 75, signatureY - 10, 60, 25);
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('For Maurya Khad Beej Bhandar', pageWidth - 70, signatureY - 4);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 128);
  doc.text('Ramprasad Maurya', pageWidth - 70, signatureY + 6);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text('Authorized Proprietor Sign & Stamp', pageWidth - 70, signatureY + 11);

  // Customer acknowledgement box
  doc.rect(14, signatureY - 10, 60, 25);
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('Customer Verification & Signature', 18, signatureY - 4);
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text('I confirm the above ledger balance is correct.', 18, signatureY + 8);

  // Draw header and footers on all pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    drawHeader(i, totalPages);
  }

  return doc.output('blob');
}

export function downloadPdfBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
