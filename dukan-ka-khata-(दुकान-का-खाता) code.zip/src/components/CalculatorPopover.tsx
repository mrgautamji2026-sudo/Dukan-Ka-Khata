import React, { useState } from 'react';
import { Calculator, X, Delete } from 'lucide-react';
import { useTranslation } from '../context/LanguageContext';

export const CalculatorPopover: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [display, setDisplay] = useState('0');
  const [prevVal, setPrevVal] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewVal, setWaitingForNewVal] = useState(false);
  const { t } = useTranslation();

  const handleDigit = (digit: string) => {
    if (waitingForNewVal) {
      setDisplay(digit);
      setWaitingForNewVal(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  };

  const handleDecimal = () => {
    if (waitingForNewVal) {
      setDisplay('0.');
      setWaitingForNewVal(false);
      return;
    }
    if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleOp = (op: string) => {
    const current = parseFloat(display);
    if (prevVal === null) {
      setPrevVal(current);
    } else if (operation) {
      const result = calculate(prevVal, current, operation);
      setPrevVal(result);
      setDisplay(String(result));
    }
    setWaitingForNewVal(true);
    setOperation(op);
  };

  const calculate = (a: number, b: number, op: string): number => {
    switch (op) {
      case '+': return a + b;
      case '-': return a - b;
      case '×': return a * b;
      case '÷': return b !== 0 ? Math.round((a / b) * 100) / 100 : 0;
      default: return b;
    }
  };

  const handleEquals = () => {
    if (prevVal !== null && operation) {
      const current = parseFloat(display);
      const result = calculate(prevVal, current, operation);
      setDisplay(String(result));
      setPrevVal(null);
      setOperation(null);
      setWaitingForNewVal(true);
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setPrevVal(null);
    setOperation(null);
    setWaitingForNewVal(false);
  };

  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  };

  return (
    <div className="relative">
      <button
        id="btn-calculator-toggle"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white font-medium text-sm transition shadow-sm"
        title={t('quickCalculator')}
      >
        <Calculator className="w-4 h-4 text-white" />
        <span className="hidden sm:inline">{t('quickCalculator')}</span>
      </button>

      {isOpen && (
        <div
          id="popover-calculator-window"
          className="absolute right-0 mt-2 z-50 w-72 bg-white rounded-xl shadow-2xl border border-gray-200 p-4 transition-all"
        >
          <div className="flex items-center justify-between pb-2 border-b border-gray-100">
            <span className="text-xs font-bold uppercase tracking-wider text-navy-800 flex items-center gap-1.5 text-[#000080]">
              <Calculator className="w-4 h-4 text-[#FF9933]" />
              {t('quickCalculator')}
            </span>
            <button
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-gray-700 p-1 rounded-md"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Calculator Screen */}
          <div className="my-3 bg-gray-900 text-right p-3 rounded-lg text-white font-mono text-2xl font-bold tracking-tight overflow-x-auto shadow-inner">
            <div className="text-xs text-gray-400 font-sans h-4">
              {prevVal !== null ? `${prevVal} ${operation || ''}` : ''}
            </div>
            <div className="text-emerald-400 font-bold truncate">₹ {display}</div>
          </div>

          {/* Keypad Grid */}
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={handleClear}
              className="col-span-2 py-2 text-sm font-bold bg-rose-100 text-rose-700 rounded-lg hover:bg-rose-200 transition"
            >
              C
            </button>
            <button
              onClick={handleBackspace}
              className="py-2 flex items-center justify-center text-sm font-semibold bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition"
            >
              <Delete className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleOp('÷')}
              className="py-2 text-sm font-bold bg-amber-100 text-[#FF9933] rounded-lg hover:bg-amber-200 transition"
            >
              ÷
            </button>

            {['7', '8', '9'].map(d => (
              <button
                key={d}
                onClick={() => handleDigit(d)}
                className="py-2 text-base font-semibold bg-gray-50 text-gray-800 rounded-lg hover:bg-gray-100 border border-gray-200 transition"
              >
                {d}
              </button>
            ))}
            <button
              onClick={() => handleOp('×')}
              className="py-2 text-sm font-bold bg-amber-100 text-[#FF9933] rounded-lg hover:bg-amber-200 transition"
            >
              ×
            </button>

            {['4', '5', '6'].map(d => (
              <button
                key={d}
                onClick={() => handleDigit(d)}
                className="py-2 text-base font-semibold bg-gray-50 text-gray-800 rounded-lg hover:bg-gray-100 border border-gray-200 transition"
              >
                {d}
              </button>
            ))}
            <button
              onClick={() => handleOp('-')}
              className="py-2 text-sm font-bold bg-amber-100 text-[#FF9933] rounded-lg hover:bg-amber-200 transition"
            >
              -
            </button>

            {['1', '2', '3'].map(d => (
              <button
                key={d}
                onClick={() => handleDigit(d)}
                className="py-2 text-base font-semibold bg-gray-50 text-gray-800 rounded-lg hover:bg-gray-100 border border-gray-200 transition"
              >
                {d}
              </button>
            ))}
            <button
              onClick={() => handleOp('+')}
              className="py-2 text-sm font-bold bg-amber-100 text-[#FF9933] rounded-lg hover:bg-amber-200 transition"
            >
              +
            </button>

            <button
              onClick={() => handleDigit('0')}
              className="col-span-2 py-2 text-base font-semibold bg-gray-50 text-gray-800 rounded-lg hover:bg-gray-100 border border-gray-200 transition"
            >
              0
            </button>
            <button
              onClick={handleDecimal}
              className="py-2 text-base font-semibold bg-gray-50 text-gray-800 rounded-lg hover:bg-gray-100 border border-gray-200 transition"
            >
              .
            </button>
            <button
              onClick={handleEquals}
              className="py-2 text-base font-bold bg-[#138808] text-white rounded-lg hover:bg-emerald-700 transition shadow"
            >
              =
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
