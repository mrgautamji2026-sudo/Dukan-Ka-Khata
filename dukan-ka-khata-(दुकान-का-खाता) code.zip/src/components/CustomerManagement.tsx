import React, { useState } from 'react';
import {
  UserPlus,
  AlertTriangle,
  FileText,
  PlusCircle,
  Phone,
  ShieldAlert,
  Calendar,
  IndianRupee,
  Share2,
  CheckCircle2,
  AlertOctagon,
  X,
  CreditCard,
  Building,
} from 'lucide-react';
import type { Customer, Transaction } from '../types';
import { useTranslation } from '../context/LanguageContext';
import { calculateDaysElapsed } from '../services/telemetryGateway';

interface CustomerManagementProps {
  customers: Customer[];
  transactions: Transaction[];
  activeTab: 'standard' | 'defaulters';
  onTabChange: (tab: 'standard' | 'defaulters') => void;
  onSelectCustomer: (customer: Customer) => void;
  onOpenNewTransaction: (customer: Customer, forcePaymentOnly?: boolean) => void;
  onSaveCustomer: (customerData: Partial<Customer>) => Promise<void>;
  onToggleBlacklist: (customerId: string, currentState: boolean) => Promise<void>;
  onExportCustomerPdf: (customer: Customer) => void;
}

export const CustomerManagement: React.FC<CustomerManagementProps> = ({
  customers,
  transactions,
  activeTab,
  onTabChange,
  onSelectCustomer,
  onOpenNewTransaction,
  onSaveCustomer,
  onToggleBlacklist,
  onExportCustomerPdf,
}) => {
  const { t, language } = useTranslation();
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  // Form State
  const [fullName, setFullName] = useState('');
  const [primaryMobile, setPrimaryMobile] = useState('');
  const [alternateMobile, setAlternateMobile] = useState('');
  const [aadharNumber, setAadharNumber] = useState('');
  const [address, setAddress] = useState('');
  const [isBlacklisted, setIsBlacklisted] = useState(false);
  const [formError, setFormError] = useState('');

  // Blocking Warning Dialog State for Red Flagged Customers
  const [blockingCustomer, setBlockingCustomer] = useState<Customer | null>(null);

  // Filter & Sort Logic
  const sortedCustomers = React.useMemo(() => {
    if (activeTab === 'defaulters') {
      // Strictly ordered descending by maximum outstanding balance (credit minus debit)
      return [...customers].sort(
        (a, b) => b.netOutstandingBalance - a.netOutstandingBalance
      );
    }
    // Standard View: Alphabetical by Full Name
    return [...customers].sort((a, b) => a.fullName.localeCompare(b.fullName));
  }, [customers, activeTab]);

  const openAddCustomer = (cust?: Customer) => {
    if (cust) {
      setEditingCustomer(cust);
      setFullName(cust.fullName);
      setPrimaryMobile(cust.primaryMobile);
      setAlternateMobile(cust.alternateMobile || '');
      setAadharNumber(cust.aadharNumber || '');
      setAddress(cust.address || '');
      setIsBlacklisted(cust.isBlacklisted || false);
    } else {
      setEditingCustomer(null);
      setFullName('');
      setPrimaryMobile('');
      setAlternateMobile('');
      setAadharNumber('');
      setAddress('');
      setIsBlacklisted(false);
    }
    setFormError('');
    setShowAddModal(true);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!fullName.trim()) {
      setFormError(t('nameRequired'));
      return;
    }

    // Client-side 10-digit mobile check
    const cleanPhone = primaryMobile.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setFormError(t('phoneInvalid'));
      return;
    }

    // Client-side 12-digit Aadhar format checking (Regex check)
    // Allows format "123456789012" or "1234 5678 9012"
    const aadharClean = aadharNumber.replace(/\s+/g, '');
    if (aadharClean && !/^\d{12}$/.test(aadharClean)) {
      setFormError(t('aadharInvalid'));
      return;
    }

    const payload: Partial<Customer> = {
      ...(editingCustomer ? { id: editingCustomer.id } : {}),
      fullName: fullName.trim(),
      primaryMobile: cleanPhone,
      alternateMobile: alternateMobile.replace(/\D/g, '') || '',
      aadharNumber: aadharClean.replace(/(\d{4})(\d{4})(\d{4})/, '$1 $2 $3'),
      address: address.trim(),
      isBlacklisted,
    };

    await onSaveCustomer(payload);
    setShowAddModal(false);
  };

  // Intercept click on "New Transaction" or customer selection
  const handleInitiateTransaction = (customer: Customer) => {
    if (customer.isBlacklisted) {
      // Trigger un-dismissible blocking modal warning dialog
      setBlockingCustomer(customer);
    } else {
      onOpenNewTransaction(customer);
    }
  };

  return (
    <div className="space-y-4">
      {/* Tabbed Dashboard Header Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-2 sm:p-3 rounded-2xl border border-gray-200 shadow-xs">
        <div className="flex items-center gap-1.5 p-1 bg-gray-100 rounded-xl">
          <button
            id="tab-standard-customers"
            onClick={() => onTabChange('standard')}
            className={`px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition ${
              activeTab === 'standard'
                ? 'bg-white text-[#000080] shadow-xs'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            {t('customersTab')} ({customers.length})
          </button>
          <button
            id="tab-top-defaulters"
            onClick={() => onTabChange('defaulters')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition ${
              activeTab === 'defaulters'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-red-700 hover:bg-red-50'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            {t('defaultersTab')}
          </button>
        </div>

        <button
          id="btn-add-customer-modal-open"
          onClick={() => openAddCustomer()}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#FF9933] hover:bg-amber-600 text-white font-bold text-sm rounded-xl transition shadow-xs"
        >
          <UserPlus className="w-4 h-4" />
          {t('addCustomer')}
        </button>
      </div>

      {/* Customer Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        {sortedCustomers.length === 0 ? (
          <div className="col-span-full py-12 text-center text-gray-400 bg-white rounded-2xl border border-dashed border-gray-300">
            <UserPlus className="w-10 h-10 mx-auto mb-2 text-gray-300" />
            <p className="text-sm font-semibold">{t('noCustomersFound')}</p>
          </div>
        ) : (
          sortedCustomers.map(cust => {
            const daysElapsed = calculateDaysElapsed(cust.initialCreditDate || cust.createdAt);
            const isHighDue = cust.netOutstandingBalance > 20000;

            return (
              <div
                key={cust.id}
                id={`customer-card-${cust.id}`}
                className={`bg-white rounded-2xl p-4 transition-all duration-200 relative overflow-hidden flex flex-col justify-between ${
                  cust.isBlacklisted
                    ? 'border-2 border-red-500 animate-pulse-warning shadow-md'
                    : 'border border-gray-200 hover:border-[#FF9933] hover:shadow-md'
                }`}
              >
                {/* Defaulter / Blacklist Ribbon */}
                {cust.isBlacklisted && (
                  <div className="bg-red-600 text-white px-3 py-1 -mx-4 -mt-4 mb-3 flex items-center justify-between text-xs font-bold uppercase tracking-wider">
                    <span className="flex items-center gap-1.5">
                      <AlertOctagon className="w-3.5 h-3.5 text-white" />
                      {t('blacklisted')}
                    </span>
                    <span className="text-[10px] bg-red-800 px-1.5 py-0.5 rounded">
                      {language === 'hi' ? 'उधार निषेध' : 'HIGH RISK'}
                    </span>
                  </div>
                )}

                <div>
                  {/* Top Customer Info Row */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3
                        onClick={() => onSelectCustomer(cust)}
                        className="font-bold text-base text-gray-900 hover:text-[#000080] cursor-pointer flex items-center gap-1.5"
                      >
                        {cust.fullName}
                      </h3>
                      <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                        <span className="flex items-center gap-1 font-mono">
                          <Phone className="w-3 h-3 text-[#138808]" />
                          +91 {cust.primaryMobile}
                        </span>
                        {cust.address && (
                          <span className="text-gray-400 truncate max-w-[130px]">
                            • {cust.address}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Blacklist Toggle Switch */}
                    <button
                      onClick={() => onToggleBlacklist(cust.id, cust.isBlacklisted)}
                      className={`p-1.5 rounded-lg text-xs font-semibold transition ${
                        cust.isBlacklisted
                          ? 'bg-red-100 text-red-700 hover:bg-red-200'
                          : 'bg-gray-100 text-gray-500 hover:bg-red-50 hover:text-red-600'
                      }`}
                      title={cust.isBlacklisted ? t('unmarkDefaulter') : t('markDefaulter')}
                    >
                      <AlertTriangle className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Aadhar & Identity Meta */}
                  {cust.aadharNumber && (
                    <div className="mt-2.5 flex items-center gap-1.5 text-[11px] text-gray-500 font-mono bg-gray-50 px-2.5 py-1 rounded-lg border border-gray-100">
                      <CreditCard className="w-3 h-3 text-[#000080]" />
                      <span>UIDAI Aadhar: {cust.aadharNumber}</span>
                    </div>
                  )}

                  {/* Financial Balance Summary Matrix */}
                  <div className="mt-3.5 p-3 rounded-xl bg-gray-50/80 border border-gray-100">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-semibold text-gray-500">
                        {t('outstandingDue')}
                      </span>
                      <span
                        className={`text-lg font-black tracking-tight ${
                          cust.netOutstandingBalance > 0
                            ? 'text-red-600'
                            : 'text-[#138808]'
                        }`}
                      >
                        ₹{cust.netOutstandingBalance.toLocaleString('en-IN')}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] pt-1.5 border-t border-gray-200/60">
                      <div>
                        <span className="text-gray-400">{t('totalGiven')}:</span>
                        <span className="ml-1 font-semibold text-gray-700">
                          ₹{cust.totalCreditGiven.toLocaleString('en-IN')}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-gray-400">{t('totalPaid')}:</span>
                        <span className="ml-1 font-semibold text-[#138808]">
                          ₹{cust.totalPaymentReceived.toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>

                    {cust.initialCreditDate && cust.netOutstandingBalance > 0 && (
                      <div className="mt-2 text-[11px] text-amber-700 bg-amber-50/80 px-2 py-0.5 rounded flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-[#FF9933]" />
                        <span>
                          {language === 'hi'
                            ? `उधार अवधि: ${daysElapsed} दिन`
                            : `Credit age: ${daysElapsed} days`}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="mt-4 pt-2.5 border-t border-gray-100 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onSelectCustomer(cust)}
                    className="flex-1 py-1.5 px-2 bg-gray-100 hover:bg-gray-200 text-[#000080] rounded-lg text-xs font-bold transition flex items-center justify-center gap-1"
                  >
                    <FileText className="w-3.5 h-3.5 text-[#000080]" />
                    {t('viewHistory')}
                  </button>

                  <button
                    onClick={() => onExportCustomerPdf(cust)}
                    className="p-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs transition"
                    title="Export PDF Passbook"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => handleInitiateTransaction(cust)}
                    className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold text-white transition flex items-center justify-center gap-1 shadow-xs ${
                      cust.isBlacklisted
                        ? 'bg-red-600 hover:bg-red-700'
                        : 'bg-[#138808] hover:bg-emerald-700'
                    }`}
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    {t('newTransaction')}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* UN-DISMISSIBLE BLOCKING WARNING MODAL FOR BLACKLISTED / BAD DEBT CUSTOMERS */}
      {blockingCustomer && (
        <div
          id="un-dismissible-blocking-warning-dialog"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs"
        >
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border-4 border-red-600 overflow-hidden animate-bounce-short">
            {/* Pulsing Warning Banner */}
            <div className="bg-red-600 p-4 text-white text-center">
              <ShieldAlert className="w-12 h-12 mx-auto text-amber-300 animate-pulse mb-1" />
              <h3 className="font-black text-lg tracking-wide uppercase">
                {t('blacklistWarningTitle')}
              </h3>
            </div>

            <div className="p-5 text-center">
              <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 mb-4">
                <p className="text-sm font-bold text-red-900 leading-snug font-hindi">
                  {t('blacklistWarningMessage')}
                </p>
                <p className="text-xs text-red-700 mt-2 font-medium">
                  {t('blacklistWarningHindi')}
                </p>
              </div>

              {/* Customer Debt Profile Details */}
              <div className="text-left bg-gray-50 rounded-xl p-3.5 mb-5 border border-gray-200 text-xs">
                <div className="flex justify-between py-1 border-b border-gray-200">
                  <span className="text-gray-500 font-semibold">{t('fullName')}:</span>
                  <span className="font-bold text-gray-900">{blockingCustomer.fullName}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-gray-200">
                  <span className="text-gray-500 font-semibold">{t('primaryPhone')}:</span>
                  <span className="font-mono text-gray-800">+91 {blockingCustomer.primaryMobile}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-gray-500 font-semibold">{t('outstandingDue')}:</span>
                  <span className="font-black text-red-600 text-sm">
                    ₹{blockingCustomer.netOutstandingBalance.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-2.5">
                <button
                  id="btn-accept-payment-only"
                  onClick={() => {
                    const cust = blockingCustomer;
                    setBlockingCustomer(null);
                    onOpenNewTransaction(cust, true); // payment only
                  }}
                  className="w-full py-3 bg-[#138808] hover:bg-emerald-700 text-white font-bold text-sm rounded-xl transition shadow"
                >
                  {t('recordPaymentOnly')}
                </button>

                <button
                  id="btn-proceed-caution"
                  onClick={() => {
                    const cust = blockingCustomer;
                    setBlockingCustomer(null);
                    onOpenNewTransaction(cust, false);
                  }}
                  className="w-full py-2.5 bg-amber-100 hover:bg-amber-200 text-amber-900 font-semibold text-xs rounded-xl transition border border-amber-300"
                >
                  {t('proceedWithCaution')}
                </button>

                <button
                  id="btn-cancel-blocking-dialog"
                  onClick={() => setBlockingCustomer(null)}
                  className="w-full py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 font-medium text-xs rounded-xl transition"
                >
                  {t('closeWarning')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ADD / EDIT CUSTOMER MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
            <div className="bg-[#FF9933] p-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-base sm:text-lg flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-white" />
                {editingCustomer ? t('editCustomer') : t('addCustomer')}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="p-5 space-y-4">
              {formError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-500" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  {t('fullName')} *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  placeholder={language === 'hi' ? 'उदा. रामेश्वर सिंह यादव' : 'e.g. Rameshwar Singh Yadav'}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#000080] focus:ring-1 focus:ring-blue-900"
                />
              </div>

              {/* Mobile Numbers */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    {t('primaryPhone')} * (10 Digits)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-xs text-gray-400 font-mono">+91</span>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={primaryMobile}
                      onChange={e => setPrimaryMobile(e.target.value)}
                      placeholder="9839012345"
                      className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-gray-300 text-sm font-mono focus:outline-none focus:border-[#000080]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    {t('alternatePhone')} (वैकल्पिक)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-xs text-gray-400 font-mono">+91</span>
                    <input
                      type="tel"
                      maxLength={10}
                      value={alternateMobile}
                      onChange={e => setAlternateMobile(e.target.value)}
                      placeholder="9450123456"
                      className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-gray-300 text-sm font-mono focus:outline-none focus:border-[#000080]"
                    />
                  </div>
                </div>
              </div>

              {/* 12-Digit Aadhar Card with Regex format checking */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  {t('aadharNumber')} (12-Digit UIDAI)
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    maxLength={14}
                    value={aadharNumber}
                    onChange={e => {
                      // Automatically format as "XXXX XXXX XXXX"
                      const raw = e.target.value.replace(/\D/g, '').slice(0, 12);
                      const formatted = raw.replace(/(\d{4})(?=\d)/g, '$1 ');
                      setAadharNumber(formatted);
                    }}
                    placeholder="5421 8974 1230"
                    className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-gray-300 text-sm font-mono tracking-wider focus:outline-none focus:border-[#000080]"
                  />
                </div>
                <p className="text-[11px] text-gray-400 mt-1">
                  {language === 'hi'
                    ? '12 अंकों का वैध आधार कार्ड नंबर दर्ज करें'
                    : 'Enter valid 12-digit UIDAI Aadhar number format'}
                </p>
              </div>

              {/* Village / Address */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  {t('address')}
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder={language === 'hi' ? 'ग्राम मोलनापुर टोला, आजमगढ़' : 'Village Molnapur Tola, Azamgarh'}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#000080]"
                />
              </div>

              {/* Red Flag Bad Debt / Blacklist Toggle Switch */}
              <div className="p-3.5 bg-red-50/70 rounded-xl border border-red-200 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-red-900 flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-red-600" />
                    {t('blacklisted')}
                  </span>
                  <p className="text-[11px] text-red-700 mt-0.5">
                    {language === 'hi'
                      ? 'इस ग्राहक को लाल घेरे और चेतावनी में रखें (डिफाल्टर लिस्ट)'
                      : 'Flag account with red pulsing warning border and credit block'}
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isBlacklisted}
                    onChange={e => setIsBlacklisted(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
                </label>
              </div>

              {/* Footer Form Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 transition"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-[#138808] hover:bg-emerald-700 transition shadow"
                >
                  {t('saveCustomer')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
