import React, { useState, useRef } from 'react';
import {
  Package,
  Plus,
  Search,
  AlertTriangle,
  Camera,
  Mic,
  Trash2,
  Edit2,
  Tag,
  Check,
  X,
  Play,
  Square,
  ArrowUpDown,
  Filter,
} from 'lucide-react';
import type { InventoryItem, UnitType } from '../types';
import { useTranslation } from '../context/LanguageContext';

interface InventoryLedgerProps {
  items: InventoryItem[];
  onSaveItem: (itemData: Partial<InventoryItem>) => Promise<void>;
  onDeleteItem: (id: string) => Promise<void>;
  onUpdateStock: (id: string, newStock: number) => Promise<void>;
}

const CATEGORIES = [
  'Fertilisers (खाद)',
  'Seeds (बीज)',
  'Pesticides (कीटनाशक)',
  'Groceries (किराना)',
  'Grains (अनाज)',
  'General / Others (अन्य)',
];

const UNIT_OPTIONS: { label: string; value: UnitType }[] = [
  { label: 'kg (किलोग्राम)', value: 'kg' },
  { label: 'gram (ग्राम)', value: 'gram' },
  { label: 'piece (नग / पीस)', value: 'piece' },
  { label: 'litre (लीटर)', value: 'litre' },
  { label: 'packet (पैकेट / बोरी)', value: 'packet' },
];

export const InventoryLedger: React.FC<InventoryLedgerProps> = ({
  items,
  onSaveItem,
  onDeleteItem,
  onUpdateStock,
}) => {
  const { t, language } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [pricePerUnit, setPricePerUnit] = useState<number>(100);
  const [unit, setUnit] = useState<UnitType>('kg');
  const [stockQuantity, setStockQuantity] = useState<number>(50);
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(10);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [voiceTagBase64, setVoiceTagBase64] = useState<string | null>(null);

  // Audio recording state for SKU voice tags
  const [isRecordingTag, setIsRecordingTag] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  const filteredItems = items.filter(it => {
    const matchesCategory = selectedCategory === 'All' || it.category === selectedCategory;
    const matchesSearch =
      it.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      it.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const openAddEditModal = (item?: InventoryItem) => {
    if (item) {
      setEditingItem(item);
      setName(item.name);
      setCategory(item.category);
      setPricePerUnit(item.pricePerUnit);
      setUnit(item.unit);
      setStockQuantity(item.stockQuantity);
      setLowStockThreshold(item.lowStockThreshold);
      setImageBase64(item.imageBase64 || null);
      setVoiceTagBase64(item.voiceTagAudioBase64 || null);
    } else {
      setEditingItem(null);
      setName('');
      setCategory(CATEGORIES[0]);
      setPricePerUnit(100);
      setUnit('kg');
      setStockQuantity(50);
      setLowStockThreshold(10);
      setImageBase64(null);
      setVoiceTagBase64(null);
    }
    setShowModal(true);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const max = 640;
        let w = img.width;
        let h = img.height;
        if (w > max || h > max) {
          if (w > h) {
            h = Math.round((h * max) / w);
            w = max;
          } else {
            w = Math.round((w * max) / h);
            h = max;
          }
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, w, h);
        setImageBase64(canvas.toDataURL('image/jpeg', 0.65));
      };
      img.src = ev.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Voice tag recorder
  const startVoiceTag = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mr = new MediaRecorder(stream);
      mediaRecorderRef.current = mr;

      mr.ondataavailable = e => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mr.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => setVoiceTagBase64(reader.result as string);
        reader.readAsDataURL(blob);
        stream.getTracks().forEach(t => t.stop());
      };

      mr.start();
      setIsRecordingTag(true);
    } catch {
      alert('Microphone permission required for voice tag.');
    }
  };

  const stopVoiceTag = () => {
    if (mediaRecorderRef.current && isRecordingTag) {
      mediaRecorderRef.current.stop();
      setIsRecordingTag(false);
    }
  };

  const handlePlayTag = (audioBase64: string, id: string) => {
    if (playingAudioId === id && audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      setPlayingAudioId(null);
      return;
    }
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
    }
    const audio = new Audio(audioBase64);
    audio.onended = () => setPlayingAudioId(null);
    audio.play();
    audioPlayerRef.current = audio;
    setPlayingAudioId(id);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    await onSaveItem({
      ...(editingItem ? { id: editingItem.id } : {}),
      name: name.trim(),
      category,
      pricePerUnit,
      unit,
      stockQuantity,
      lowStockThreshold,
      imageBase64: imageBase64 || undefined,
      voiceTagAudioBase64: voiceTagBase64 || undefined,
    });

    setShowModal(false);
  };

  return (
    <div id="dukan-stock-ledger-matrix" className="space-y-4">
      {/* Header & Controls Bar */}
      <div className="bg-white p-3 sm:p-4 rounded-2xl border border-gray-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-gray-900 flex items-center gap-2 font-hindi-heading">
            <Package className="w-5 h-5 text-[#FF9933]" />
            {t('stockLedgerTitle')}
          </h2>
          <p className="text-xs text-gray-500">
            {language === 'hi'
              ? 'दुकान में उपलब्ध खाद, बीज, कीटनाशक व किराना सामान का स्टॉक व मूल्य'
              : 'Live inventory stock counts, dynamic unit pricing, and low-stock alerts'}
          </p>
        </div>

        <button
          id="btn-add-product-modal-open"
          onClick={() => openAddEditModal()}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#138808] hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl transition shadow-xs"
        >
          <Plus className="w-4 h-4" />
          {t('addNewProduct')}
        </button>
      </div>

      {/* Category Matrix Chips & Search Filter */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center gap-2.5">
        {/* Category Matrix */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`px-3 py-1.5 rounded-xl font-bold transition shrink-0 ${
              selectedCategory === 'All'
                ? 'bg-[#000080] text-white shadow-xs'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {t('allCategories')} ({items.length})
          </button>
          {CATEGORIES.map(cat => {
            const count = items.filter(i => i.category === cat).length;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl font-bold transition shrink-0 ${
                  selectedCategory === cat
                    ? 'bg-[#000080] text-white shadow-xs'
                    : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                {cat} ({count})
              </button>
            );
          })}
        </div>

        {/* Search within Inventory */}
        <div className="relative md:w-64 shrink-0">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={language === 'hi' ? 'सामान खोजें...' : 'Search stock...'}
            className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-gray-200 text-xs bg-white focus:outline-none focus:border-[#000080]"
          />
        </div>
      </div>

      {/* Inventory Items Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {filteredItems.length === 0 ? (
          <div className="col-span-full py-12 text-center text-gray-400 bg-white rounded-2xl border border-dashed border-gray-300">
            <Package className="w-10 h-10 mx-auto mb-2 text-gray-300" />
            <p className="text-sm font-semibold">{language === 'hi' ? 'कोई सामान नहीं मिला' : 'No items found'}</p>
          </div>
        ) : (
          filteredItems.map(item => {
            const isLowStock = item.stockQuantity <= item.lowStockThreshold;

            return (
              <div
                key={item.id}
                id={`inventory-card-${item.id}`}
                className={`bg-white rounded-2xl p-4 border transition flex flex-col justify-between ${
                  isLowStock
                    ? 'border-amber-400 bg-amber-50/20'
                    : 'border-gray-200 hover:border-[#FF9933]'
                } shadow-xs hover:shadow-md`}
              >
                <div>
                  {/* Category Tag & Actions */}
                  <div className="flex items-center justify-between gap-1 mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#000080] bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100">
                      {item.category.split(' ')[0]}
                    </span>

                    <div className="flex items-center gap-1">
                      {item.voiceTagAudioBase64 && (
                        <button
                          onClick={() => handlePlayTag(item.voiceTagAudioBase64!, item.id)}
                          className={`p-1 rounded-md text-xs ${
                            playingAudioId === item.id
                              ? 'bg-red-500 text-white'
                              : 'bg-amber-100 text-[#FF9933] hover:bg-amber-200'
                          }`}
                          title="Play Voice Tag Note"
                        >
                          {playingAudioId === item.id ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        </button>
                      )}
                      <button
                        onClick={() => openAddEditModal(item)}
                        className="p-1 text-gray-400 hover:text-gray-700 rounded-md hover:bg-gray-100"
                        title="Edit"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteItem(item.id)}
                        className="p-1 text-gray-400 hover:text-red-600 rounded-md hover:bg-red-50"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Thumbnail Image if attached */}
                  {item.imageBase64 && (
                    <img
                      src={item.imageBase64}
                      alt={item.name}
                      className="w-full h-28 object-cover rounded-xl mb-2.5 border border-gray-200"
                    />
                  )}

                  {/* Product Title & Rate */}
                  <h4 className="font-bold text-sm text-gray-900 leading-snug line-clamp-2">
                    {item.name}
                  </h4>

                  <div className="mt-2 flex items-baseline justify-between">
                    <div>
                      <span className="text-xs text-gray-400">दर (Rate):</span>
                      <span className="ml-1 text-base font-black text-[#000080]">
                        ₹{item.pricePerUnit}
                      </span>
                      <span className="text-xs text-gray-500">/{item.unit}</span>
                    </div>

                    {isLowStock ? (
                      <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-amber-600" />
                        कम स्टॉक
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-[#138808] bg-emerald-50 px-2 py-0.5 rounded-full">
                        {t('inStock')}
                      </span>
                    )}
                  </div>
                </div>

                {/* Stock Counter with Quick Adjustment Nodes */}
                <div className="mt-3 pt-2.5 border-t border-gray-100">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-gray-500">
                      {t('stockCount')}:
                    </span>
                    <span className="font-mono font-bold text-sm text-gray-800">
                      {item.stockQuantity} {item.unit}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 mt-2">
                    <button
                      onClick={() => onUpdateStock(item.id, Math.max(0, item.stockQuantity - 1))}
                      className="flex-1 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs rounded-lg transition"
                    >
                      -1
                    </button>
                    <button
                      onClick={() => onUpdateStock(item.id, Math.max(0, item.stockQuantity - 5))}
                      className="flex-1 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs rounded-lg transition"
                    >
                      -5
                    </button>
                    <button
                      onClick={() => onUpdateStock(item.id, item.stockQuantity + 5)}
                      className="flex-1 py-1 bg-emerald-50 hover:bg-emerald-100 text-[#138808] font-bold text-xs rounded-lg transition"
                    >
                      +5
                    </button>
                    <button
                      onClick={() => onUpdateStock(item.id, item.stockQuantity + 10)}
                      className="flex-1 py-1 bg-emerald-50 hover:bg-emerald-100 text-[#138808] font-bold text-xs rounded-lg transition"
                    >
                      +10
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add / Edit Inventory Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
            <div className="bg-[#138808] p-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-base flex items-center gap-2">
                <Package className="w-5 h-5 text-white" />
                {editingItem ? 'Edit Product SKU' : t('addNewProduct')}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5">
              {/* Product Name */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  {t('productName')} *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder={language === 'hi' ? 'उदा. डीएपी 18:46:0 खाद' : 'e.g. DAP 18:46:0 Fertilizer'}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#000080]"
                />
              </div>

              {/* Category Matrix Selector */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  {t('category')}
                </label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#000080]"
                >
                  {CATEGORIES.map(c => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              {/* Price & Strict Unit Dropdown */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    {t('unitPrice')} *
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={pricePerUnit}
                    onChange={e => setPricePerUnit(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 text-sm font-mono focus:outline-none focus:border-[#000080]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    {t('unitType')} *
                  </label>
                  <select
                    value={unit}
                    onChange={e => setUnit(e.target.value as UnitType)}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 text-sm font-bold text-[#000080] focus:outline-none focus:border-[#000080]"
                  >
                    {UNIT_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Stock Quantity & Low Stock Threshold */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    {t('stockCount')}
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={stockQuantity}
                    onChange={e => setStockQuantity(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 text-sm font-mono focus:outline-none focus:border-[#000080]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    {t('lowStockThreshold')}
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={lowStockThreshold}
                    onChange={e => setLowStockThreshold(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 text-sm font-mono focus:outline-none focus:border-[#000080]"
                  />
                </div>
              </div>

              {/* Dynamic Image & Voice Tag Attachments */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    {t('productImage')}
                  </label>
                  <label className="flex items-center justify-center gap-1.5 p-2 bg-gray-50 border border-gray-300 rounded-xl text-xs text-gray-600 cursor-pointer hover:bg-gray-100">
                    <Camera className="w-3.5 h-3.5 text-[#000080]" />
                    <span>{imageBase64 ? 'Replace' : 'Upload'}</span>
                    <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                  </label>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    {t('voiceTag')}
                  </label>
                  {isRecordingTag ? (
                    <button
                      type="button"
                      onClick={stopVoiceTag}
                      className="w-full py-2 bg-red-600 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1 animate-pulse"
                    >
                      <Square className="w-3.5 h-3.5" /> Stop
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={startVoiceTag}
                      className="w-full py-2 bg-gray-50 border border-gray-300 text-gray-700 font-semibold text-xs rounded-xl hover:bg-gray-100 flex items-center justify-center gap-1"
                    >
                      <Mic className="w-3.5 h-3.5 text-[#FF9933]" />
                      <span>{voiceTagBase64 ? 'Re-record' : 'Record'}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 transition"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#138808] hover:bg-emerald-700 transition shadow"
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
