import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import confetti from 'canvas-confetti';
import {
  X,
  Camera,
  Mic,
  MicOff,
  QrCode,
  Lock,
  Eye,
  EyeOff,
  Trash2,
  Play,
  Square,
  Plus,
  Minus,
  CheckCircle2,
  Sparkles,
  Send,
  MessageCircle,
  FileCheck,
  Smartphone,
  AlertCircle
} from 'lucide-react';
import type { Customer, Transaction, TransactionType, VoiceItemToken, StoreSettings } from '../types';
import { useTranslation } from '../context/LanguageContext';
import { tokenizeVoiceDictation, createSpeechRecognizer } from '../services/voiceParser';
import { dispatchTransactionalCommunication, SENDER_IDENTITY } from '../services/telemetryGateway';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: Customer;
  storeSettings: StoreSettings;
  forcePaymentOnly?: boolean;
  onSaveTransaction: (
    transactionData: Omit<Transaction, 'id' | 'createdAt' | 'syncStatus'>
  ) => Promise<void>;
  onUpdateCustomerBalance: (
    customerId: string,
    deltaCredit: number,
    deltaPayment: number
  ) => Promise<void>;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  customer,
  storeSettings,
  forcePaymentOnly = false,
  onSaveTransaction,
  onUpdateCustomerBalance,
}) => {
  const { t, language } = useTranslation();

  // Transaction state
  const [txnType, setTxnType] = useState<TransactionType>(
    forcePaymentOnly ? 'PAYMENT_RECEIVED' : 'CREDIT_GIVEN'
  );
  const [totalBill, setTotalBill] = useState<number>(100);
  const [paidAmount, setPaidAmount] = useState<number>(forcePaymentOnly ? 100 : 0);
  const [note, setNote] = useState<string>('');
  const [items, setItems] = useState<VoiceItemToken[]>([]);

  // Speech-to-text dictation state
  const [isDictating, setIsDictating] = useState(false);
  const dictationRecognizerRef = useRef<any>(null);

  // Camera capture state
  const [cameraActive, setCameraActive] = useState(false);
  const [billImageBase64, setBillImageBase64] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Voice Note Recording state
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [voiceAudioBase64, setVoiceAudioBase64] = useState<string | null>(null);
  const [audioDuration, setAudioDuration] = useState<number>(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioTimerRef = useRef<any>(null);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Dynamic UPI QR Canvas state
  const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [showQrCode, setShowQrCode] = useState<boolean>(storeSettings.showUpiQrCode);

  // Native timestamp
  const nativeTimestamp = useRef(new Date().toISOString());

  // Post-save notification preview state
  const [savedSuccessData, setSavedSuccessData] = useState<{
    whatsappUrl: string;
    smsUrl: string;
    messageBody: string;
  } | null>(null);

  // Remaining due calculation: totalBill - paidAmount
  const remainingDue = Math.max(0, totalBill - paidAmount);

  // Quick Adjustment Steps
  const stepAmounts = [10, 50, 100];

  const handleStepBill = (delta: number) => {
    setTotalBill(prev => Math.max(0, prev + delta));
  };

  const handleStepPaid = (delta: number) => {
    setPaidAmount(prev => Math.max(0, Math.min(totalBill, prev + delta)));
  };

  // Generate dynamic UPI string
  // upi://pay?pa=OWNER_VPA&pn=OWNER_NAME&am=REMAINING_DUE&cu=INR
  useEffect(() => {
    if (!isOpen) return;

    const amountForQr = txnType === 'CREDIT_GIVEN' ? remainingDue : paidAmount;
    if (amountForQr > 0 && qrCanvasRef.current && showQrCode) {
      const vpa = storeSettings.ownerVpa || 'mauryafertilizer@oksbi';
      const ownerName = encodeURIComponent(storeSettings.ownerName || 'Maurya Khad Beej Bhandar');
      const upiUrl = `upi://pay?pa=${vpa}&pn=${ownerName}&am=${amountForQr}&cu=INR`;

      QRCode.toCanvas(
        qrCanvasRef.current,
        upiUrl,
        {
          width: 170,
          margin: 1,
          color: {
            dark: '#000080', // Ashoka Navy Blue
            light: '#FFFFFF',
          },
        },
        err => {
          if (err) console.error('UPI QR Error:', err);
        }
      );
    }
  }, [isOpen, remainingDue, paidAmount, txnType, showQrCode, storeSettings]);

  // Clean up media streams on close
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      stopVoiceRecording();
      setSavedSuccessData(null);
    }
  }, [isOpen]);

  // --- Voice Dictation Logic ---
  const toggleDictation = () => {
    if (isDictating) {
      if (dictationRecognizerRef.current) {
        dictationRecognizerRef.current.stop();
      }
      setIsDictating(false);
      return;
    }

    const recognizer = createSpeechRecognizer(
      transcript => {
        setNote(prev => (prev ? `${prev} ${transcript}` : transcript));
        // Parse words through local regex tokenizer
        const detectedItems = tokenizeVoiceDictation(transcript);
        if (detectedItems.length > 0) {
          setItems(prev => [...prev, ...detectedItems]);
        }
      },
      err => {
        console.warn('Dictation error:', err);
        setIsDictating(false);
      }
    );

    if (!recognizer) {
      alert(t('speechNotSupported'));
      return;
    }

    recognizer.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
    recognizer.onend = () => setIsDictating(false);

    try {
      recognizer.start();
      dictationRecognizerRef.current = recognizer;
      setIsDictating(true);
    } catch (e) {
      console.warn('Cannot start dictation:', e);
      setIsDictating(false);
    }
  };

  // --- Camera Capture Component Logic (720p compressed JPG) ---
  const startCamera = async () => {
    try {
      setCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'environment',
        },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.warn('Camera access denied or unavailable, using file upload fallback:', err);
      // Fallback: trigger file input
      document.getElementById('bill-photo-fallback-input')?.click();
      setCameraActive(false);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 1280;
    canvas.height = videoRef.current.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      // Compress to 720p JPG at 0.7 quality for lightweight storage
      const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
      setBillImageBase64(dataUrl);
    }
    stopCamera();
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = event => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 1280;
        let w = img.width;
        let h = img.height;
        if (w > maxDim || h > maxDim) {
          if (w > h) {
            h = Math.round((h * maxDim) / w);
            w = maxDim;
          } else {
            w = Math.round((w * maxDim) / h);
            h = maxDim;
          }
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, w, h);
        setBillImageBase64(canvas.toDataURL('image/jpeg', 0.7));
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // --- Voice Note Recording Component Logic (MediaRecorder API) ---
  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = e => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm;codecs=opus' });
        const reader = new FileReader();
        reader.onloadend = () => {
          setVoiceAudioBase64(reader.result as string);
        };
        reader.readAsDataURL(audioBlob);

        // Stop all audio tracks
        stream.getTracks().forEach(t => t.stop());
        clearInterval(audioTimerRef.current);
      };

      mediaRecorder.start(250);
      setIsRecordingAudio(true);
      setAudioDuration(0);

      audioTimerRef.current = setInterval(() => {
        setAudioDuration(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.warn('Microphone permission denied or not supported:', err);
      alert('Microphone access is needed to record voice notes.');
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorderRef.current && isRecordingAudio) {
      mediaRecorderRef.current.stop();
      setIsRecordingAudio(false);
      clearInterval(audioTimerRef.current);
    }
  };

  const togglePlayAudioPreview = () => {
    if (!voiceAudioBase64) return;
    if (isPlayingPreview && audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      setIsPlayingPreview(false);
    } else {
      if (!audioPlayerRef.current) {
        audioPlayerRef.current = new Audio(voiceAudioBase64);
        audioPlayerRef.current.onended = () => setIsPlayingPreview(false);
      }
      audioPlayerRef.current.play();
      setIsPlayingPreview(true);
    }
  };

  // --- Save Transaction Execution ---
  const handleSave = async () => {
    if (totalBill <= 0 && paidAmount <= 0) {
      alert('Please enter a valid bill or payment amount.');
      return;
    }

    const finalBill = txnType === 'PAYMENT_RECEIVED' ? paidAmount : totalBill;
    const finalPaid = txnType === 'PAYMENT_RECEIVED' ? paidAmount : paidAmount;
    const calculatedDue = Math.max(0, finalBill - finalPaid);

    const transactionPayload: Omit<Transaction, 'id' | 'createdAt' | 'syncStatus'> = {
      customerId: customer.id,
      customerName: customer.fullName,
      customerPhone: customer.primaryMobile,
      type: txnType,
      totalBill: finalBill,
      paidAmount: finalPaid,
      remainingDue: calculatedDue,
      note: note.trim(),
      items: items.length > 0 ? items : undefined,
      billImageBase64: billImageBase64 || undefined,
      voiceNoteAudioBase64: voiceAudioBase64 || undefined,
      voiceNoteDurationSec: audioDuration || undefined,
    };

    // 1. Save Transaction to local IndexedDB via Dexie
    await onSaveTransaction(transactionPayload);

    // 2. Update Customer Balance
    const deltaCredit = txnType === 'CREDIT_GIVEN' ? finalBill : 0;
    const deltaPayment = finalPaid;
    await onUpdateCustomerBalance(customer.id, deltaCredit, deltaPayment);

    // 3. Trigger Confetti celebration on debt settlement
    if (txnType === 'PAYMENT_RECEIVED' || calculatedDue === 0) {
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FF9933', '#FFFFFF', '#138808', '#000080'],
      });
    }

    // 4. Fire background communication engine targeting SMS & WhatsApp
    const dummyTxn: Transaction = {
      ...transactionPayload,
      id: `txn-${Date.now()}`,
      createdAt: nativeTimestamp.current,
      syncStatus: 'pending',
    };

    const updatedCustomer: Customer = {
      ...customer,
      netOutstandingBalance:
        txnType === 'CREDIT_GIVEN'
          ? customer.netOutstandingBalance + (finalBill - finalPaid)
          : Math.max(0, customer.netOutstandingBalance - finalPaid),
      totalCreditGiven: customer.totalCreditGiven + deltaCredit,
      totalPaymentReceived: customer.totalPaymentReceived + deltaPayment,
    };

    const commResult = await dispatchTransactionalCommunication(
      updatedCustomer,
      dummyTxn,
      language
    );

    setSavedSuccessData({
      whatsappUrl: commResult.whatsappUrl,
      smsUrl: commResult.smsUrl,
      messageBody: commResult.outboxItem.messageBody,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-2 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div
        id="modal-transaction-pipeline"
        className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden my-4"
      >
        {/* Header Ribbon */}
        <div className="bg-[#FF9933] p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center font-bold text-lg">
              ₹
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg leading-tight">
                {txnType === 'CREDIT_GIVEN' ? t('recordCreditGiven') : t('recordPaymentReceived')}
              </h3>
              <p className="text-xs text-amber-100 font-medium">
                {customer.fullName} (+91 {customer.primaryMobile})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Successful Save Screen with WhatsApp & SMS Send Triggers */}
        {savedSuccessData ? (
          <div className="p-6 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-[#138808] rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <h3 className="text-xl font-bold text-gray-900">
              {t('transactionSavedSuccess')}
            </h3>

            <p className="text-xs text-gray-500 max-w-md mx-auto">
              {t('smsWhatsAppSent')}
            </p>

            {/* Outbox notification preview card */}
            <div className="bg-gray-50 p-4 rounded-xl text-left border border-gray-200 font-mono text-xs whitespace-pre-wrap max-h-48 overflow-y-auto text-gray-700">
              {savedSuccessData.messageBody}
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <a
                href={savedSuccessData.whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 py-3 bg-[#25D366] hover:bg-[#1EBE5D] text-white font-bold text-sm rounded-xl transition shadow"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp Alert
              </a>

              <a
                href={savedSuccessData.smsUrl}
                className="flex items-center justify-center gap-2 py-3 bg-[#000080] hover:bg-blue-900 text-white font-bold text-sm rounded-xl transition shadow"
              >
                <Smartphone className="w-4 h-4" />
                SMS Alert
              </a>
            </div>

            <button
              onClick={onClose}
              className="mt-4 w-full py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl text-xs transition"
            >
              {t('close')}
            </button>
          </div>
        ) : (
          /* Normal Transaction Form View */
          <div className="p-4 sm:p-6 space-y-4 max-h-[80vh] overflow-y-auto">
            
            {/* Transaction Type Switcher */}
            {!forcePaymentOnly && (
              <div className="grid grid-cols-2 gap-2 p-1 bg-gray-100 rounded-xl">
                <button
                  type="button"
                  id="tab-credit-given"
                  onClick={() => {
                    setTxnType('CREDIT_GIVEN');
                    setPaidAmount(0);
                  }}
                  className={`py-2 text-xs sm:text-sm font-bold rounded-lg transition ${
                    txnType === 'CREDIT_GIVEN'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {t('recordCreditGiven')}
                </button>
                <button
                  type="button"
                  id="tab-payment-received"
                  onClick={() => {
                    setTxnType('PAYMENT_RECEIVED');
                    setPaidAmount(totalBill);
                  }}
                  className={`py-2 text-xs sm:text-sm font-bold rounded-lg transition ${
                    txnType === 'PAYMENT_RECEIVED'
                      ? 'bg-[#138808] text-white shadow-xs'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {t('recordPaymentReceived')}
                </button>
              </div>
            )}

            {/* Calculations & Quick Step Pads */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 bg-gray-50 p-3.5 rounded-2xl border border-gray-200">
              
              {/* Total Bill Input & Step Pad */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  {t('totalBillAmount')} *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-base font-bold text-gray-400">₹</span>
                  <input
                    type="number"
                    min={0}
                    value={totalBill}
                    onChange={e => setTotalBill(Number(e.target.value) || 0)}
                    className="w-full pl-8 pr-3 py-2 text-lg font-black text-gray-900 rounded-xl border border-gray-300 focus:outline-none focus:border-[#FF9933] bg-white font-mono"
                  />
                </div>

                {/* Quick Step Buttons for Bill */}
                <div className="flex items-center gap-1.5 mt-2">
                  <span className="text-[10px] text-gray-400 font-semibold">{t('quickAdjustment')}:</span>
                  {stepAmounts.map(amt => (
                    <button
                      key={`bill-plus-${amt}`}
                      type="button"
                      onClick={() => handleStepBill(amt)}
                      className="px-2 py-1 text-xs font-bold bg-amber-100 hover:bg-amber-200 text-[#FF9933] rounded-lg transition"
                    >
                      +{amt}
                    </button>
                  ))}
                  {stepAmounts.map(amt => (
                    <button
                      key={`bill-minus-${amt}`}
                      type="button"
                      onClick={() => handleStepBill(-amt)}
                      className="px-2 py-1 text-xs font-bold bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg transition"
                    >
                      -{amt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Paid Now Input & Step Pad */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  {t('paidNowAmount')}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-base font-bold text-[#138808]">₹</span>
                  <input
                    type="number"
                    min={0}
                    value={paidAmount}
                    onChange={e => setPaidAmount(Number(e.target.value) || 0)}
                    className="w-full pl-8 pr-3 py-2 text-lg font-black text-[#138808] rounded-xl border border-gray-300 focus:outline-none focus:border-[#138808] bg-white font-mono"
                  />
                </div>

                {/* Quick Step Buttons for Paid */}
                <div className="flex items-center gap-1.5 mt-2">
                  <span className="text-[10px] text-gray-400 font-semibold">{t('quickAdjustment')}:</span>
                  {stepAmounts.map(amt => (
                    <button
                      key={`paid-plus-${amt}`}
                      type="button"
                      onClick={() => handleStepPaid(amt)}
                      className="px-2 py-1 text-xs font-bold bg-emerald-100 hover:bg-emerald-200 text-[#138808] rounded-lg transition"
                    >
                      +{amt}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setPaidAmount(totalBill)}
                    className="px-2 py-1 text-xs font-bold bg-[#138808] text-white rounded-lg hover:bg-emerald-700 transition"
                  >
                    {language === 'hi' ? 'पूरा चुकता' : 'Full'}
                  </button>
                </div>
              </div>
            </div>

            {/* Calculated Remaining Due Matrix */}
            <div className="flex items-center justify-between p-3.5 bg-amber-50 rounded-xl border border-[#FF9933]/30">
              <span className="text-xs font-bold text-gray-700">
                {t('remainingDueAmount')}:
              </span>
              <span
                className={`text-xl font-black font-mono tracking-tight ${
                  remainingDue > 0 ? 'text-red-600' : 'text-[#138808]'
                }`}
              >
                ₹{remainingDue.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Speech-to-Text Dictation & Items Tokenizer */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">
                  {t('voiceDictate')}
                </label>
                <button
                  type="button"
                  onClick={toggleDictation}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition shadow-xs ${
                    isDictating
                      ? 'bg-red-600 text-white animate-pulse'
                      : 'bg-amber-100 text-[#FF9933] hover:bg-amber-200'
                  }`}
                >
                  {isDictating ? (
                    <>
                      <MicOff className="w-3.5 h-3.5" />
                      Listening...
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5" />
                      {language === 'hi' ? 'बोलें (उदा. 2 किलो चीनी)' : 'Dictate Items'}
                    </>
                  )}
                </button>
              </div>

              <textarea
                value={note}
                onChange={e => {
                  setNote(e.target.value);
                  // Tokenize on manual edit too
                  const parsed = tokenizeVoiceDictation(e.target.value);
                  if (parsed.length > 0) setItems(parsed);
                }}
                rows={2}
                placeholder={
                  language === 'hi'
                    ? 'उदा. "दो किलो चीनी पांच लीटर सरसों तेल" या हाथ से टाइप करें...'
                    : 'e.g. "2 kg sugar 5 litre oil" or type description...'
                }
                className="w-full p-3 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#000080]"
              />

              {/* Parsed Items list preview */}
              {items.length > 0 && (
                <div className="mt-2 p-2.5 bg-emerald-50 rounded-xl border border-emerald-200">
                  <div className="text-[11px] font-bold text-emerald-800 mb-1 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    {t('parsedItemsFromVoice')}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {items.map((it, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 text-xs bg-white text-gray-800 px-2.5 py-1 rounded-md border border-emerald-200 font-medium shadow-2xs"
                      >
                        <span className="font-bold text-[#000080]">{it.name}</span>
                        <span className="text-gray-500 font-mono">({it.quantity})</span>
                        <button
                          type="button"
                          onClick={() => setItems(items.filter((_, i) => i !== idx))}
                          className="text-gray-400 hover:text-red-500 ml-0.5"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Multimedia Attachment Nodes: Camera & Voice Note */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              
              {/* Camera Capture Card */}
              <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-[#000080]" />
                    {t('attachBillPhoto')}
                  </span>
                  {billImageBase64 && (
                    <button
                      type="button"
                      onClick={() => setBillImageBase64(null)}
                      className="text-xs text-red-600 hover:underline flex items-center gap-0.5"
                    >
                      <Trash2 className="w-3 h-3" />
                      {t('removePhoto')}
                    </button>
                  )}
                </div>

                {cameraActive ? (
                  <div className="space-y-2">
                    <video ref={videoRef} autoPlay playsInline className="w-full h-36 rounded-lg object-cover bg-black" />
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={capturePhoto}
                        className="flex-1 py-1.5 bg-[#138808] text-white text-xs font-bold rounded-lg hover:bg-emerald-700"
                      >
                        {language === 'hi' ? 'फोटो खींचें' : 'Snap 720p'}
                      </button>
                      <button
                        type="button"
                        onClick={stopCamera}
                        className="px-3 py-1.5 bg-gray-200 text-gray-700 text-xs font-bold rounded-lg"
                      >
                        {t('cancel')}
                      </button>
                    </div>
                  </div>
                ) : billImageBase64 ? (
                  <div className="relative rounded-lg overflow-hidden border border-gray-300">
                    <img src={billImageBase64} alt="Bill attachment" className="w-full h-32 object-cover" />
                    <div className="absolute bottom-1 right-1 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded">
                      720p JPG Attached
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={startCamera}
                      className="flex-1 py-2 bg-white border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 hover:bg-gray-100 flex items-center justify-center gap-1.5"
                    >
                      <Camera className="w-4 h-4 text-[#000080]" />
                      {t('takePhoto')}
                    </button>
                    <input
                      id="bill-photo-fallback-input"
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => document.getElementById('bill-photo-fallback-input')?.click()}
                      className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 hover:bg-gray-100"
                      title="Upload from gallery"
                    >
                      📁
                    </button>
                  </div>
                )}
              </div>

              {/* Voice Note Recording Card */}
              <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                    <Mic className="w-4 h-4 text-[#FF9933]" />
                    {t('voiceNoteRecorder')}
                  </span>
                  {voiceAudioBase64 && (
                    <button
                      type="button"
                      onClick={() => {
                        setVoiceAudioBase64(null);
                        setAudioDuration(0);
                      }}
                      className="text-xs text-red-600 hover:underline flex items-center gap-0.5"
                    >
                      <Trash2 className="w-3 h-3" />
                      {t('removeVoice')}
                    </button>
                  )}
                </div>

                {isRecordingAudio ? (
                  <div className="p-3 bg-red-50 rounded-lg border border-red-200 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full bg-red-600 animate-ping" />
                      <span className="text-xs font-bold text-red-700">
                        Recording: {audioDuration}s
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={stopVoiceRecording}
                      className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg flex items-center gap-1"
                    >
                      <Square className="w-3 h-3" />
                      {t('stopRecording')}
                    </button>
                  </div>
                ) : voiceAudioBase64 ? (
                  <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={togglePlayAudioPreview}
                        className="w-7 h-7 rounded-full bg-[#000080] text-white flex items-center justify-center shadow-xs"
                      >
                        {isPlayingPreview ? <Square className="w-3 h-3" /> : <Play className="w-3 h-3 ml-0.5" />}
                      </button>
                      <span className="text-xs font-semibold text-gray-800">
                        Memo Note ({audioDuration}s)
                      </span>
                    </div>
                    <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded">
                      Attached
                    </span>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={startVoiceRecording}
                    className="w-full py-2 bg-white border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 hover:bg-gray-100 flex items-center justify-center gap-1.5"
                  >
                    <Mic className="w-4 h-4 text-[#FF9933]" />
                    {t('startRecording')}
                  </button>
                )}
              </div>
            </div>

            {/* Dynamic UPI QR Code Canvas Section with Owner Hide Toggle */}
            <div className="p-3.5 bg-blue-50/70 rounded-2xl border border-[#000080]/20">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-[#000080] flex items-center gap-1.5">
                  <QrCode className="w-4 h-4 text-[#000080]" />
                  {t('scanToPayUPI')}
                </span>

                {/* Owner Reactive Hide Toggle Checkbox */}
                <label className="flex items-center gap-1.5 text-xs text-gray-600 cursor-pointer font-medium select-none">
                  <input
                    type="checkbox"
                    checked={showQrCode}
                    onChange={e => setShowQrCode(e.target.checked)}
                    className="rounded border-gray-300 text-[#000080] focus:ring-[#000080]"
                  />
                  <span>{t('showHideQr')}</span>
                </label>
              </div>

              {showQrCode ? (
                <div className="flex items-center gap-4 bg-white p-3 rounded-xl border border-gray-200">
                  <canvas ref={qrCanvasRef} className="rounded-lg shadow-2xs shrink-0" />
                  <div className="space-y-1 text-xs">
                    <p className="font-bold text-gray-900">
                      {language === 'hi' ? 'सीधे UPI द्वारा भुगतान लें' : 'Accept Direct Payment'}
                    </p>
                    <p className="font-mono text-gray-600 text-[11px]">
                      VPA: {storeSettings.ownerVpa}
                    </p>
                    <p className="text-[#138808] font-bold text-sm">
                      Amount: ₹{(txnType === 'CREDIT_GIVEN' ? remainingDue : paidAmount).toLocaleString('en-IN')}
                    </p>
                    <p className="text-[10px] text-gray-400">
                      Supports GPay, PhonePe, Paytm, BHIM
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-white rounded-xl border border-gray-200 text-center text-gray-400">
                  <Lock className="w-6 h-6 mx-auto mb-1 text-gray-400" />
                  <p className="text-xs font-semibold">{t('qrHiddenNotice')}</p>
                </div>
              )}
            </div>

            {/* Footer Form Action Buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 transition"
              >
                {t('cancel')}
              </button>
              <button
                type="button"
                id="btn-save-transaction"
                onClick={handleSave}
                className="px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-white bg-[#138808] hover:bg-emerald-700 transition shadow flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                {t('save')}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
