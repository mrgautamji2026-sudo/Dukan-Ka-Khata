import React, { useState } from 'react';
import {
  X,
  PlusCircle,
  FileDown,
  MessageCircle,
  Smartphone,
  Calendar,
  IndianRupee,
  Phone,
  CreditCard,
  Camera,
  Mic,
  Play,
  Square,
  AlertTriangle,
  Clock,
  QrCode,
  ShieldAlert,
} from 'lucide-react';
import type { Customer, Transaction, StoreSettings } from '../types';
import { useTranslation } from '../context/LanguageContext';
import { calculateDaysElapsed, buildNotificationPayload } from '../services/telemetryGateway';

interface PassbookModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: Customer;
  transactions: Transaction[];
  storeSettings: StoreSettings;
  onNewTransaction: (customer: Customer) => void;
  onExportPdf: (customer: Customer) => void;
}

export const PassbookModal: React.FC<PassbookModalProps> = ({
  isOpen,
  onClose,
  customer,
  transactions,
  storeSettings,
  onNewTransaction,
  onExportPdf,
}) => {
  const { t, language } = useTranslation();
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const audioPlayerRef = React.useRef<HTMLAudioElement | null>(null);

  if (!isOpen) return null;

  const customerTransactions = transactions
    .filter(t => t.customerId === customer.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const daysElapsed = calculateDaysElapsed(customer.initialCreditDate || customer.createdAt);

  const handlePlayVoiceNote = (audioBase64: string, id: string) => {
    if (playingAudioId === id && audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      setPlayingAudioId(null);
      return;
    }
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
    }
    const audio = new Audio(audioBase64);
    audio.onended = () => setPlayingAudioId(null);
    audio.play();
    audioPlayerRef.current = audio;
    setPlayingAudioId(id);
  };

  // Generate WhatsApp and SMS links for sharing customer passbook
  const lastTxn = customerTransactions[0];
  const statementText = lastTxn
    ? buildNotificationPayload(customer, lastTxn, language)
    : `Dukan Ka Khata Statement: ${customer.fullName} - Balance Due: Rs. ${customer.netOutstandingBalance}`;

  const cleanPhone = customer.primaryMobile.replace(/\D/g, '');
  const internationalPhone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
  const whatsappUrl = `https://api.whatsapp.com/send?phone=${internationalPhone}&text=${encodeURIComponent(
    statementText
  )}`;
  const smsUrl = `sms:${cleanPhone}?body=${encodeURIComponent(statementText)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-2 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div
        id="modal-customer-passbook"
        className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden my-4"
      >
        {/* Saffron & Navy Blue Header */}
        <div className="bg-[#FF9933] p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-[#000080] text-white flex items-center justify-center shadow font-bold text-base">
              खाता
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg leading-tight flex items-center gap-1.5 font-hindi-heading">
                {customer.fullName}
                {customer.isBlacklisted && (
                  <span className="text-[10px] bg-red-600 text-white px-2 py-0.5 rounded-full font-sans uppercase">
                    {t('blacklisted')}
                  </span>
                )}
              </h3>
              <p className="text-xs text-amber-100 font-mono">
                +91 {customer.primaryMobile} {customer.alternateMobile ? `| Alt: +91 ${customer.alternateMobile}` : ''}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Customer Balance Ribbon */}
        <div className="p-4 bg-gray-50 border-b border-gray-200">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-2.5 bg-white rounded-xl border border-gray-200 shadow-2xs">
              <span className="text-[10px] font-bold text-gray-400 uppercase">
                {t('outstandingDue')}
              </span>
              <div
                className={`text-lg sm:text-xl font-black font-mono mt-0.5 ${
                  customer.netOutstandingBalance > 0 ? 'text-red-600' : 'text-[#138808]'
                }`}
              >
                ₹{customer.netOutstandingBalance.toLocaleString('en-IN')}
              </div>
            </div>

            <div className="p-2.5 bg-white rounded-xl border border-gray-200 shadow-2xs">
              <span className="text-[10px] font-bold text-gray-400 uppercase">
                {t('totalGiven')}
              </span>
              <div className="text-base sm:text-lg font-bold text-gray-800 font-mono mt-0.5">
                ₹{customer.totalCreditGiven.toLocaleString('en-IN')}
              </div>
            </div>

            <div className="p-2.5 bg-white rounded-xl border border-gray-200 shadow-2xs">
              <span className="text-[10px] font-bold text-gray-400 uppercase">
                {t('totalPaid')}
              </span>
              <div className="text-base sm:text-lg font-bold text-[#138808] font-mono mt-0.5">
                ₹{customer.totalPaymentReceived.toLocaleString('en-IN')}
              </div>
            </div>

            <div className="p-2.5 bg-white rounded-xl border border-gray-200 shadow-2xs">
              <span className="text-[10px] font-bold text-gray-400 uppercase">
                {language === 'hi' ? 'उधार अवधि' : 'Loan Duration'}
              </span>
              <div className="text-base sm:text-lg font-bold text-[#000080] font-mono mt-0.5">
                {daysElapsed} {language === 'hi' ? 'दिन' : 'Days'}
              </div>
            </div>
          </div>

          {/* Quick Statement Share & PDF Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-3 border-t border-gray-200">
            <div className="flex items-center gap-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#25D366] hover:bg-[#1EBE5D] text-white font-bold text-xs rounded-lg shadow-2xs transition"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                WhatsApp
              </a>
              <a
                href={smsUrl}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#000080] hover:bg-blue-900 text-white font-bold text-xs rounded-lg shadow-2xs transition"
              >
                <Smartphone className="w-3.5 h-3.5" />
                SMS
              </a>
              <button
                onClick={() => onExportPdf(customer)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-700 hover:bg-gray-800 text-white font-bold text-xs rounded-lg shadow-2xs transition"
              >
                <FileDown className="w-3.5 h-3.5" />
                PDF Passbook
              </button>
            </div>

            <button
              onClick={() => onNewTransaction(customer)}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-[#138808] hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-lg shadow transition"
            >
              <PlusCircle className="w-4 h-4" />
              {t('newTransaction')}
            </button>
          </div>
        </div>

        {/* Transactions Ledger Table */}
        <div className="p-4 max-h-96 overflow-y-auto">
          <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
            {t('transactionsTab')} ({customerTransactions.length})
          </h4>

          {customerTransactions.length === 0 ? (
            <div className="py-8 text-center text-gray-400 text-xs font-medium">
              No transactions recorded yet for this customer.
            </div>
          ) : (
            <div className="space-y-2.5">
              {customerTransactions.map(txn => {
                const dateStr = new Date(txn.createdAt).toLocaleDateString(
                  language === 'hi' ? 'hi-IN' : 'en-IN',
                  {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  }
                );

                return (
                  <div
                    key={txn.id}
                    className="p-3 bg-white rounded-xl border border-gray-200 hover:border-gray-300 transition flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                            txn.type === 'CREDIT_GIVEN'
                              ? 'bg-amber-100 text-[#FF9933]'
                              : 'bg-emerald-100 text-[#138808]'
                          }`}
                        >
                          {txn.type === 'CREDIT_GIVEN'
                            ? language === 'hi'
                              ? 'उधार दिया'
                              : 'Credit Given'
                            : language === 'hi'
                            ? 'जमा / मिला'
                            : 'Payment Received'}
                        </span>
                        <span className="text-xs text-gray-400 font-mono flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {dateStr}
                        </span>
                      </div>

                      {/* Note or Items */}
                      <p className="text-xs text-gray-800 font-medium">
                        {txn.note || (txn.items?.map(i => `${i.name} (${i.quantity})`).join(', ') || '-')}
                      </p>

                      {/* Media Badges */}
                      <div className="flex items-center gap-2 pt-0.5">
                        {txn.billImageBase64 && (
                          <button
                            onClick={() => setPreviewImage(txn.billImageBase64!)}
                            className="text-[11px] text-[#000080] hover:underline flex items-center gap-1 font-semibold"
                          >
                            <Camera className="w-3 h-3" />
                            {language === 'hi' ? 'पर्ची देखें' : 'View Bill'}
                          </button>
                        )}
                        {txn.voiceNoteAudioBase64 && (
                          <button
                            onClick={() => handlePlayVoiceNote(txn.voiceNoteAudioBase64!, txn.id)}
                            className={`text-[11px] px-2 py-0.5 rounded flex items-center gap-1 font-semibold ${
                              playingAudioId === txn.id
                                ? 'bg-red-500 text-white'
                                : 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                            }`}
                          >
                            {playingAudioId === txn.id ? (
                              <Square className="w-3 h-3" />
                            ) : (
                              <Play className="w-3 h-3" />
                            )}
                            {language === 'hi' ? 'आवाज सुनें' : 'Audio Memo'}
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Numeric Amounts Column */}
                    <div className="text-right sm:border-l sm:border-gray-100 sm:pl-4">
                      <div className="text-xs text-gray-400">
                        {t('totalBillAmount')}:{' '}
                        <span className="font-bold text-gray-800">
                          ₹{txn.totalBill.toLocaleString('en-IN')}
                        </span>
                      </div>
                      <div className="text-xs text-[#138808]">
                        {t('paidNowAmount')}:{' '}
                        <span className="font-bold">
                          ₹{txn.paidAmount.toLocaleString('en-IN')}
                        </span>
                      </div>
                      <div className="text-sm font-black text-red-600 font-mono mt-0.5">
                        {language === 'hi' ? 'बाकी' : 'Due'}: ₹
                        {txn.remainingDue.toLocaleString('en-IN')}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Image Attachment Preview Modal */}
        {previewImage && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 p-4">
            <div className="relative max-w-xl max-h-[85vh] bg-white rounded-2xl p-2">
              <button
                onClick={() => setPreviewImage(null)}
                className="absolute top-4 right-4 p-1.5 bg-black/60 text-white rounded-full hover:bg-black"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={previewImage}
                alt="Bill preview"
                className="max-h-[80vh] w-auto rounded-xl object-contain mx-auto"
              />
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-3 bg-gray-50 border-t border-gray-200 text-right">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold rounded-xl text-xs transition"
          >
            {t('close')}
          </button>
        </div>
      </div>
    </div>
  );
};
