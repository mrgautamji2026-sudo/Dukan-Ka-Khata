import React, { useState, useEffect, useRef } from 'react';
import { Search, Mic, MicOff, X, Calendar, User, Package, Phone } from 'lucide-react';
import { useTranslation } from '../context/LanguageContext';
import { createSpeechRecognizer } from '../services/voiceParser';

interface VoiceSearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  activeFilterType?: 'all' | 'customer' | 'inventory' | 'date';
  onFilterTypeChange?: (type: 'all' | 'customer' | 'inventory' | 'date') => void;
}

export const VoiceSearchBar: React.FC<VoiceSearchBarProps> = ({
  searchQuery,
  onSearchChange,
  activeFilterType = 'all',
  onFilterTypeChange,
}) => {
  const { t, language } = useTranslation();
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  const toggleVoiceSearch = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    const recognition = createSpeechRecognizer(
      transcript => {
        onSearchChange(transcript);
        setIsListening(false);
      },
      err => {
        console.warn('Speech search error:', err);
        setIsListening(false);
      }
    );

    if (!recognition) {
      alert(t('speechNotSupported'));
      return;
    }

    recognition.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
    recognition.onend = () => setIsListening(false);

    try {
      recognition.start();
      recognitionRef.current = recognition;
      setIsListening(true);
    } catch (err) {
      console.warn('Could not start recognition:', err);
      setIsListening(false);
    }
  };

  return (
    <div className="w-full my-3">
      <div
        id="voice-search-utility-bar"
        className={`relative flex items-center bg-white rounded-2xl border transition shadow-xs ${
          isListening
            ? 'border-red-500 ring-2 ring-red-100'
            : 'border-gray-200 focus-within:border-[#FF9933] focus-within:ring-2 focus-within:ring-amber-100'
        }`}
      >
        <div className="pl-4 pr-2 text-gray-400">
          <Search className="w-5 h-5 text-gray-400" />
        </div>

        <input
          id="global-voice-search-input"
          type="text"
          value={searchQuery}
          onChange={e => onSearchChange(e.target.value)}
          placeholder={isListening ? t('listeningSpeech') : t('searchPlaceholder')}
          className="w-full py-3.5 pr-20 text-sm sm:text-base text-gray-800 placeholder-gray-400 bg-transparent focus:outline-none"
        />

        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="p-1.5 mr-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition"
            title="Clear"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Embedded Microphone Asset */}
        <button
          id="btn-voice-search-mic"
          type="button"
          onClick={toggleVoiceSearch}
          className={`flex items-center justify-center mr-2 w-10 h-10 rounded-xl transition shadow-xs ${
            isListening
              ? 'bg-red-600 text-white animate-pulse'
              : 'bg-amber-50 text-[#FF9933] hover:bg-amber-100 hover:text-amber-700'
          }`}
          title={isListening ? 'Stop Voice' : 'Search with Voice (बोलकर खोजें)'}
        >
          {isListening ? (
            <MicOff className="w-5 h-5 text-white" />
          ) : (
            <Mic className="w-5 h-5" />
          )}
        </button>
      </div>

      {/* Quick Search Helper Tags */}
      <div className="flex items-center gap-1.5 mt-2 overflow-x-auto pb-1 text-xs text-gray-500">
        <span className="font-semibold text-gray-400 shrink-0">
          {language === 'hi' ? 'खोज फिल्टर:' : 'Quick Filters:'}
        </span>
        <button
          onClick={() => onFilterTypeChange?.('all')}
          className={`px-2.5 py-1 rounded-lg font-medium transition shrink-0 ${
            activeFilterType === 'all'
              ? 'bg-[#000080] text-white'
              : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          {language === 'hi' ? 'सभी' : 'All'}
        </button>
        <button
          onClick={() => onFilterTypeChange?.('customer')}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition shrink-0 ${
            activeFilterType === 'customer'
              ? 'bg-[#000080] text-white'
              : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          <User className="w-3 h-3 text-[#FF9933]" />
          {language === 'hi' ? 'ग्राहक' : 'Customers'}
        </button>
        <button
          onClick={() => onFilterTypeChange?.('inventory')}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition shrink-0 ${
            activeFilterType === 'inventory'
              ? 'bg-[#000080] text-white'
              : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          <Package className="w-3 h-3 text-[#138808]" />
          {language === 'hi' ? 'दुकान सामग्री' : 'Inventory'}
        </button>
        <button
          onClick={() => onSearchChange(new Date().toISOString().split('T')[0])}
          className="flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium bg-white text-gray-600 border border-gray-200 hover:bg-gray-50 transition shrink-0"
        >
          <Calendar className="w-3 h-3 text-blue-600" />
          {language === 'hi' ? 'आज की तारीख' : "Today's Date"}
        </button>
      </div>
    </div>
  );
};
