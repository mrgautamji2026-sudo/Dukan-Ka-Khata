import React, { useState } from 'react';
import { QrCode, Download, Wifi, WifiOff, RefreshCw, BookOpen } from 'lucide-react';
import { useTranslation } from '../context/LanguageContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { CalculatorPopover } from './CalculatorPopover';
import { AppDownloadQRModal } from './AppDownloadQRModal';

interface HeaderProps {
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSettings }) => {
  const { language, toggleLanguage, t } = useTranslation();
  const { isOnline, isSyncing, pendingSyncCount, triggerSync } = useOnlineStatus();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showQRModal, setShowQRModal] = useState(false);
  const [showIOSModal, setShowIOSModal] = useState(false);

  return (
    <>
      <header
        id="app-global-header"
        className="fixed top-0 left-0 right-0 z-40 bg-[#FF9933] text-white shadow-md transition-all select-none border-b-2 border-amber-600/30"
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
          
          {/* Brand & Digital Pen/Book Emblem */}
          <div className="flex items-center gap-2.5 sm:gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            {/* Ashoka Blue Digital Pen & Book SVG Vector */}
            <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-md p-1.5 border border-amber-200">
              <svg viewBox="0 0 48 48" fill="none" className="w-full h-full">
                {/* Book Base (Ashoka Blue #000080) */}
                <rect x="6" y="8" width="30" height="34" rx="4" fill="#000080" />
                <rect x="10" y="11" width="24" height="28" rx="2" fill="#FFFFFF" />
                {/* Ruled ledger lines */}
                <line x1="14" y1="18" x2="30" y2="18" stroke="#FF9933" strokeWidth="1.5" />
                <line x1="14" y1="24" x2="30" y2="24" stroke="#000080" strokeWidth="1.5" strokeOpacity="0.4" />
                <line x1="14" y1="30" x2="30" y2="30" stroke="#138808" strokeWidth="1.5" />
                {/* Digital stylus pen diagonally */}
                <path d="M 22 14 L 38 34 L 35 38 L 19 18 Z" fill="#FF9933" />
                <polygon points="35,38 38,34 42,42" fill="#000080" />
                <circle cx="21" cy="16" r="1.5" fill="#FFFFFF" />
              </svg>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-base sm:text-xl tracking-tight leading-none text-white drop-shadow-xs font-hindi-heading">
                  {t('appName')}
                </h1>
                <span className="text-[10px] sm:text-xs bg-[#000080] text-white px-2 py-0.5 rounded-full font-semibold shadow-xs">
                  {language === 'hi' ? 'दुकान बहीखाता' : 'PWA Ledger'}
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-amber-100 font-medium truncate max-w-[190px] sm:max-w-none">
                {t('storeName')}
              </p>
            </div>
          </div>

          {/* Action Center */}
          <div className="flex items-center gap-1.5 sm:gap-3">
            
            {/* Connectivity & Sync Badge */}
            <div
              onClick={triggerSync}
              className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1 rounded-full text-xs font-semibold cursor-pointer transition shadow-xs ${
                isOnline
                  ? 'bg-emerald-800/80 text-white hover:bg-emerald-900'
                  : 'bg-rose-700 text-white animate-pulse'
              }`}
              title={isOnline ? t('onlineModeMsg') : t('offlineModeMsg')}
            >
              {isOnline ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-emerald-300" />
                  <span className="hidden md:inline">{t('onlineStatus')}</span>
                  {pendingSyncCount > 0 && (
                    <span className="bg-amber-400 text-gray-900 text-[10px] px-1.5 rounded-full font-bold">
                      {pendingSyncCount}
                    </span>
                  )}
                  {isSyncing && <RefreshCw className="w-3 h-3 animate-spin text-white" />}
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-rose-200" />
                  <span>{t('offlineStatus')}</span>
                </>
              )}
            </div>

            {/* Quick Calculator Popover */}
            <CalculatorPopover />

            {/* App Mirror QR Downloader Trigger */}
            <button
              id="btn-qr-app-downloader"
              onClick={() => setShowQRModal(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white font-medium text-xs sm:text-sm transition shadow-sm"
              title={t('qrAppDownload')}
            >
              <QrCode className="w-4 h-4 text-white" />
              <span className="hidden lg:inline">{t('qrAppDownload')}</span>
            </button>

            {/* In-App PWA Install Button */}
            {isInstallable && (
              <button
                id="btn-pwa-install-app"
                onClick={install}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#000080] hover:bg-blue-900 text-white font-bold text-xs sm:text-sm transition shadow"
              >
                <Download className="w-4 h-4 text-amber-300" />
                <span className="hidden sm:inline">{t('pwaInstall')}</span>
              </button>
            )}

            {isIOS && !isInstalled && (
              <button
                onClick={() => setShowIOSModal(true)}
                className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[#000080] text-white text-xs font-semibold"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">iOS Install</span>
              </button>
            )}

            {/* Language Toggle Switch (EN / हिं) */}
            <button
              id="btn-language-toggle"
              onClick={toggleLanguage}
              className="flex items-center rounded-lg bg-white/25 hover:bg-white/35 p-1 text-xs font-bold text-white border border-white/40 transition shadow-sm"
              title="Switch Language / भाषा बदलें"
            >
              <span
                className={`px-2 py-0.5 rounded-md transition ${
                  language === 'en' ? 'bg-[#000080] text-white shadow-xs' : 'text-amber-100 hover:text-white'
                }`}
              >
                EN
              </span>
              <span
                className={`px-2 py-0.5 rounded-md transition ${
                  language === 'hi' ? 'bg-[#000080] text-white shadow-xs' : 'text-amber-100 hover:text-white'
                }`}
              >
                हिं
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* App Mirror QR Modal */}
      <AppDownloadQRModal isOpen={showQRModal} onClose={() => setShowQRModal(false)} />

      {/* iOS Safari Guide Modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-gray-900">
              {language === 'hi' ? 'iPhone / iPad पर इंस्टॉल करें' : 'Install on iPhone / iPad'}
            </h3>
            <p className="mt-3 text-sm text-gray-600 leading-relaxed">
              1. Safari ब्राउज़र के नीचे स्थित <strong>Share</strong> बटन दबाएं।<br />
              2. नीचे स्क्रॉल करें और <strong>Add to Home Screen (होम स्क्रीन में जोड़ें)</strong> चुनें।
            </p>
            <button
              onClick={() => setShowIOSModal(false)}
              className="mt-5 w-full rounded-xl bg-[#FF9933] text-white py-2 text-sm font-bold hover:bg-amber-600 transition"
            >
              {t('close')}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
