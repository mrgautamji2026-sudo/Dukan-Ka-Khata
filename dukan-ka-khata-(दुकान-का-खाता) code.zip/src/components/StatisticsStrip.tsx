import React from 'react';
import { IndianRupee, TrendingUp, Users, PackageCheck } from 'lucide-react';
import { useTranslation } from '../context/LanguageContext';

interface StatisticsStripProps {
  totalOutstandingDebt: number;
  totalPaidToday: number;
  activeCustomerBase: number;
  totalInventorySKUs: number;
  onFilterDefaulters?: () => void;
  onViewInventory?: () => void;
  onViewCustomers?: () => void;
}

export const StatisticsStrip: React.FC<StatisticsStripProps> = ({
  totalOutstandingDebt,
  totalPaidToday,
  activeCustomerBase,
  totalInventorySKUs,
  onFilterDefaulters,
  onViewInventory,
  onViewCustomers,
}) => {
  const { t } = useTranslation();

  return (
    <div
      id="core-statistics-strip"
      className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 my-4"
    >
      {/* 1. Total Outstanding Debt (कुल बकाया) */}
      <div
        id="stat-card-total-debt"
        onClick={onFilterDefaulters}
        className="bg-white rounded-2xl p-3.5 sm:p-4 border border-red-100 shadow-xs hover:shadow-md transition cursor-pointer group relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 right-0 h-1 bg-red-500" />
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
            {t('totalDebt')}
          </span>
          <div className="w-8 h-8 rounded-xl bg-red-50 text-red-600 flex items-center justify-center group-hover:scale-110 transition">
            <IndianRupee className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-1">
          <span className="text-xl sm:text-2xl font-black text-red-600 tracking-tight">
            ₹{totalOutstandingDebt.toLocaleString('en-IN')}
          </span>
        </div>
        <div className="mt-1 text-[11px] text-gray-400 font-medium truncate">
          {t('totalDebtSub')}
        </div>
      </div>

      {/* 2. Total Paid Today (आज की वसूली) */}
      <div
        id="stat-card-paid-today"
        className="bg-white rounded-2xl p-3.5 sm:p-4 border border-emerald-100 shadow-xs hover:shadow-md transition relative overflow-hidden group"
      >
        <div className="absolute top-0 left-0 right-0 h-1 bg-[#138808]" />
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
            {t('totalPaidToday')}
          </span>
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#138808] flex items-center justify-center group-hover:scale-110 transition">
            <TrendingUp className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-1">
          <span className="text-xl sm:text-2xl font-black text-[#138808] tracking-tight">
            ₹{totalPaidToday.toLocaleString('en-IN')}
          </span>
        </div>
        <div className="mt-1 text-[11px] text-gray-400 font-medium truncate">
          {t('totalPaidTodaySub')}
        </div>
      </div>

      {/* 3. Active Customer Base (सक्रिय ग्राहक) */}
      <div
        id="stat-card-active-customers"
        onClick={onViewCustomers}
        className="bg-white rounded-2xl p-3.5 sm:p-4 border border-blue-100 shadow-xs hover:shadow-md transition cursor-pointer group relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 right-0 h-1 bg-[#000080]" />
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
            {t('activeCustomers')}
          </span>
          <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#000080] flex items-center justify-center group-hover:scale-110 transition">
            <Users className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-1">
          <span className="text-xl sm:text-2xl font-black text-[#000080] tracking-tight">
            {activeCustomerBase}
          </span>
          <span className="text-xs text-gray-500 font-semibold">खाते</span>
        </div>
        <div className="mt-1 text-[11px] text-gray-400 font-medium truncate">
          {t('activeCustomersSub')}
        </div>
      </div>

      {/* 4. Total Inventory SKUs (कुल सामग्री) */}
      <div
        id="stat-card-inventory-skus"
        onClick={onViewInventory}
        className="bg-white rounded-2xl p-3.5 sm:p-4 border border-amber-100 shadow-xs hover:shadow-md transition cursor-pointer group relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 right-0 h-1 bg-[#FF9933]" />
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
            {t('totalInventory')}
          </span>
          <div className="w-8 h-8 rounded-xl bg-amber-50 text-[#FF9933] flex items-center justify-center group-hover:scale-110 transition">
            <PackageCheck className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-1">
          <span className="text-xl sm:text-2xl font-black text-amber-700 tracking-tight">
            {totalInventorySKUs}
          </span>
          <span className="text-xs text-gray-500 font-semibold">SKUs</span>
        </div>
        <div className="mt-1 text-[11px] text-gray-400 font-medium truncate">
          {t('totalInventorySub')}
        </div>
      </div>
    </div>
  );
};
