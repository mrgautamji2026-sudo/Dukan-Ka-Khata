import React, { useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { QrCode, X, Smartphone, Monitor, Download } from 'lucide-react';
import { useTranslation } from '../context/LanguageContext';

interface AppDownloadQRModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppDownloadQRModal: React.FC<AppDownloadQRModalProps> = ({ isOpen, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const { t, language } = useTranslation();

  useEffect(() => {
    if (isOpen && canvasRef.current) {
      const appUrl = window.location.href;
      QRCode.toCanvas(
        canvasRef.current,
        appUrl,
        {
          width: 220,
          margin: 2,
          color: {
            dark: '#000080', // Ashoka Navy Blue QR dots
            light: '#FFFFFF',
          },
        },
        error => {
          if (error) console.error('QR code generation error:', error);
        }
      );
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div
        id="modal-app-downloader-qr"
        className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden"
      >
        {/* Tricolour Ribbon Header */}
        <div className="bg-[#FF9933] p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <QrCode className="w-6 h-6 text-white" />
            <h3 className="font-bold text-lg">
              {language === 'hi' ? 'मोबाइल या कंप्यूटर पर खोलें' : 'Mirror on Mobile or PC'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 text-center">
          <p className="text-sm text-gray-600 mb-4">
            {language === 'hi'
              ? 'इस QR कोड को अपने मोबाइल फोन के कैमरा से स्कैन करें और "दुकान का खाता" तुरंत चलाएं।'
              : 'Scan this QR code with your smartphone camera to mirror and install Dukan Ka Khata immediately.'}
          </p>

          <div className="inline-block p-4 bg-amber-50 rounded-2xl border-2 border-dashed border-[#FF9933] shadow-inner mb-4">
            <canvas ref={canvasRef} className="mx-auto rounded-lg shadow-sm" />
            <div className="mt-2 text-xs font-semibold text-[#000080] flex items-center justify-center gap-1">
              <Download className="w-3.5 h-3.5 text-[#138808]" />
              PWA Offline-First Enabled
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-left">
            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
              <div className="flex items-center gap-2 text-xs font-bold text-gray-800 mb-1">
                <Smartphone className="w-4 h-4 text-[#FF9933]" />
                Android / iPhone
              </div>
              <p className="text-[11px] text-gray-500">
                {language === 'hi'
                  ? 'Chrome/Safari में खोलकर "Add to Home Screen" दबाएं।'
                  : 'Open browser and tap "Add to Home Screen" to install.'}
              </p>
            </div>

            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
              <div className="flex items-center gap-2 text-xs font-bold text-gray-800 mb-1">
                <Monitor className="w-4 h-4 text-[#000080]" />
                Computer / Tablet
              </div>
              <p className="text-[11px] text-gray-500">
                {language === 'hi'
                  ? 'एड्रेस बार में दिए इंस्टॉल आइकन पर क्लिक करें।'
                  : 'Click the install icon on your desktop address bar.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="mt-5 w-full py-2.5 bg-[#138808] hover:bg-emerald-700 text-white font-semibold rounded-xl text-sm transition shadow"
          >
            {t('close')}
          </button>
        </div>
      </div>
    </div>
  );
};
