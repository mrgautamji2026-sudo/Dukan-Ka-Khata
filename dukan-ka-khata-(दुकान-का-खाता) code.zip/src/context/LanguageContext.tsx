import React, { createContext, useContext, useState, useEffect } from 'react';
import type { Language } from '../types';

export const TRANSLATIONS = {
  en: {
    appName: 'Dukan Ka Khata',
    appSubtitle: 'Digital Bahikhata for Micro-Merchants',
    storeName: 'Maurya Khad Beej Bhandar, Molnapur',
    
    // Stats Strip
    totalDebt: 'Total Outstanding Debt',
    totalDebtSub: 'Pending Udhar balance',
    totalPaidToday: 'Total Paid Today',
    totalPaidTodaySub: 'Cash & UPI collected',
    activeCustomers: 'Active Customer Base',
    activeCustomersSub: 'Registered account holders',
    totalInventory: 'Total Inventory SKUs',
    totalInventorySub: 'Active product items',
    
    // Search
    searchPlaceholder: 'Voice or text search: Customer name, Mobile, Product, or Date (YYYY-MM-DD)...',
    listeningSpeech: 'Listening... Speak in Hindi or English (बोलिए...)',
    speechNotSupported: 'Speech recognition not supported in this browser.',
    
    // Navigation Tabs
    customersTab: 'Customer Khata (ग्राहक)',
    defaultersTab: 'Top Defaulters (सबसे ज़्यादा उधार)',
    inventoryTab: 'Stock Ledger (स्टॉक बही)',
    transactionsTab: 'All Transactions (लेनदेन)',
    settingsTab: 'Settings & Sync (सेटिंग्स व बैकअप)',

    // Customer CRM
    addCustomer: 'Add New Customer',
    customerList: 'Customer Accounts',
    searchCustomer: 'Search customer name or phone...',
    noCustomersFound: 'No customers found',
    primaryPhone: 'Mobile Number',
    alternatePhone: 'Alternate Mobile',
    aadharNumber: '12-digit Aadhar Number',
    fullName: 'Full Name',
    address: 'Village / Address',
    status: 'Status',
    blacklisted: 'Bad Debt / Blacklisted',
    goodStanding: 'Normal Account',
    outstandingDue: 'Net Due',
    totalGiven: 'Total Given',
    totalPaid: 'Total Received',
    action: 'Action',
    newTransaction: 'New Entry',
    viewHistory: 'Passbook',
    editCustomer: 'Edit Profile',
    deleteCustomer: 'Delete',
    markDefaulter: 'Flag as Bad Debt (ब्लैकलिस्ट)',
    unmarkDefaulter: 'Remove Flag (सामान्य करें)',
    saveCustomer: 'Save Customer Account',
    cancel: 'Cancel',
    aadharInvalid: 'Please enter a valid 12-digit Aadhar number (e.g. 1234 5678 9012)',
    phoneInvalid: 'Please enter a valid 10-digit mobile number',
    nameRequired: 'Customer name is required',

    // Blocking Red Flag Modal
    blacklistWarningTitle: 'High Credit Risk Alert!',
    blacklistWarningMessage: 'Warning: Outstanding balance high. Avoid giving further credit to this customer.',
    blacklistWarningHindi: 'चेतावनी: इस ग्राहक का बकाया बहुत अधिक है। अधिक उधार देने से बचें।',
    proceedWithCaution: 'Proceed with Caution (सावधानी से आगे बढ़ें)',
    recordPaymentOnly: 'Accept Payment Only (केवल जमा करें)',
    closeWarning: 'Go Back',

    // Transaction Pipeline
    recordCreditGiven: 'Given Credit (उधार दिया / माल दिया)',
    recordPaymentReceived: 'Received Payment (पैसा मिला / जमा)',
    totalBillAmount: 'Total Bill Amount (कुल बिल)',
    paidNowAmount: 'Paid Amount (दिया गया पैसा)',
    remainingDueAmount: 'Remaining Due (बकाया राशि)',
    quickAdjustment: 'Quick Step Pad',
    voiceDictate: 'Voice Dictate Items (बोलकर सामान जोड़ें)',
    voiceNoteRecorder: 'Record Voice Memo Note',
    attachBillPhoto: 'Attach Paper Bill / Diary Photo',
    capturedPhoto: 'Bill Photo Attached',
    recordedVoiceNote: 'Voice Memo Attached',
    playAudio: 'Play Memo',
    stopAudio: 'Stop',
    startRecording: 'Record Audio Note',
    stopRecording: 'Save Audio Recording',
    takePhoto: 'Take / Upload Photo',
    removePhoto: 'Remove Photo',
    removeVoice: 'Remove Voice',
    parsedItemsFromVoice: 'Items Detected via Speech Tokenizer:',
    transactionSavedSuccess: 'Transaction saved and logged successfully!',
    smsWhatsAppSent: 'Dispatched notification via SMS and WhatsApp API',
    
    // Dynamic UPI QR
    scanToPayUPI: 'Scan UPI QR to Pay Balance',
    showHideQr: 'Show/Hide QR Code',
    qrHiddenNotice: 'QR Code is hidden for security. Check box above to display.',
    vpaAddress: 'UPI VPA',

    // Stock Ledger
    stockLedgerTitle: 'Dukan Stock Ledger Matrix',
    addNewProduct: 'Add New Product (नया सामान)',
    productName: 'Product Name',
    category: 'Category',
    unitPrice: 'Price per Unit (₹)',
    unitType: 'Unit Type',
    stockCount: 'Current Stock',
    lowStockThreshold: 'Low Stock Alert Level',
    lowStockAlert: 'Low Stock Warning',
    inStock: 'In Stock',
    outOfStock: 'Out of Stock',
    allCategories: 'All Categories',
    productImage: 'Product Image',
    voiceTag: 'Instructional Voice Tag',

    // Settings, Backups & Sync
    settingsTitle: 'Store Settings & Cloud Sync',
    backupCadenceTitle: 'Automated Backup Cadence',
    weekly: 'Weekly',
    monthly: 'Monthly',
    yearly: 'Yearly',
    weeklyBackup: 'Weekly (साप्ताहिक)',
    monthlyBackup: 'Monthly (मासिक)',
    yearlyBackup: 'Yearly (वार्षिक)',
    cloudSyncTitle: 'Cloud Sync & Data Exports',
    googleDriveSync: 'Google Drive Sync',
    exportPdfReport: 'Download PDF Statement',
    downloadJson: 'Export JSON Backup',
    restoreJson: 'Restore from JSON',
    googleDriveSyncTitle: 'Google Drive Direct Sync',
    googleDriveSyncDesc: 'Connect local offline store directly to personal Google Drive merchant folder.',
    syncNowBtn: 'Sync Now with Cloud',
    syncSuccess: 'Local ledger securely synced with cloud storage!',
    offlineModeMsg: 'Offline Mode: Transactions queue locally and sync automatically when online.',
    onlineModeMsg: 'Online: Real-time synchronization active.',
    generatePdfReport: 'Download PDF Statement & Report',
    pdfReportDesc: 'Generate client-side multi-page statement with tricolour layout, stamp and signatures.',
    runAutomatedCronBackup: 'Trigger Scheduled Cron Backup Dispatch',
    cronDispatchedMsg: 'Automated backup PDF generated and dispatched to merchant email & backup phone!',
    merchantProfile: 'Merchant Business Identity',
    merchantName: 'Proprietor Name',
    merchantVpa: 'Merchant UPI ID',
    merchantPhone: 'Contact Number',
    merchantAddress: 'Store Location Address',
    
    // Calculator
    quickCalculator: 'Quick Calculator',
    clearCalc: 'C',
    equals: '=',

    // General
    rupeeSymbol: '₹',
    daysElapsed: 'days elapsed',
    loanDurationMsg: 'Loan balance borrowed on: {date}. Total days elapsed: {days} days from initial credit date.',
    thankYouToken: 'Thank you for shopping at Maurya Khad Beej Bhandar!',
    save: 'Save',
    confirm: 'Confirm',
    close: 'Close',
    pwaInstall: 'Install App',
    pwaInstalled: 'App Installed',
    offlineStatus: 'Offline',
    onlineStatus: 'Online',
    qrAppDownload: 'Get Mobile App (QR)',
  },
  hi: {
    appName: 'दुकान का खाता',
    appSubtitle: 'भारतीय व्यापारियों का डिजिटल बहीखाता',
    storeName: 'मौर्य खाद बीज भंडार, मोलनापुर',
    
    // Stats Strip
    totalDebt: 'कुल बकाया उधार',
    totalDebtSub: 'ग्राहकों पर बाकी रकम',
    totalPaidToday: 'आज की कुल वसूली',
    totalPaidTodaySub: 'नकद व UPI भुगतान',
    activeCustomers: 'सक्रिय ग्राहक',
    activeCustomersSub: 'पंजीकृत खाताधारक',
    totalInventory: 'कुल स्टॉक सामग्री',
    totalInventorySub: 'दुकान में कुल सामान',
    
    // Search
    searchPlaceholder: 'आवाज या लिखकर खोजें: ग्राहक का नाम, मोबाइल नंबर, सामान या तारीख (YYYY-MM-DD)...',
    listeningSpeech: 'सुन रहे हैं... बोलिए (बोलकर खोजें)',
    speechNotSupported: 'आपके ब्राउज़र में बोलकर खोजने की सुविधा उपलब्ध नहीं है।',
    
    // Navigation Tabs
    customersTab: 'ग्राहक खाता',
    defaultersTab: 'सबसे ज़्यादा उधार',
    inventoryTab: 'स्टॉक बही (इन्वेंट्री)',
    transactionsTab: 'सभी लेनदेन',
    settingsTab: 'सेटिंग्स व बैकअप',

    // Customer CRM
    addCustomer: 'नया ग्राहक जोड़ें',
    customerList: 'ग्राहक सूची',
    searchCustomer: 'ग्राहक नाम या फोन नंबर खोजें...',
    noCustomersFound: 'कोई ग्राहक नहीं मिला',
    primaryPhone: 'मोबाइल नंबर',
    alternatePhone: 'वैकल्पिक नंबर',
    aadharNumber: '12 अंकों का आधार नंबर',
    fullName: 'पूरा नाम',
    address: 'गांव / पता',
    status: 'खाता स्थिति',
    blacklisted: 'ब्लैकलिस्ट / डिफाल्टर',
    goodStanding: 'सामान्य खाता',
    outstandingDue: 'कुल बकाया',
    totalGiven: 'कुल दिया',
    totalPaid: 'कुल मिला',
    action: 'कार्रवाई',
    newTransaction: 'नया लेनदेन',
    viewHistory: 'पासबुक देखें',
    editCustomer: 'बदलाव करें',
    deleteCustomer: 'हटाएं',
    markDefaulter: 'ब्लैकलिस्ट में डालें (डिफाल्टर)',
    unmarkDefaulter: 'ब्लैकलिस्ट से हटाएं',
    saveCustomer: 'ग्राहक खाता सुरक्षित करें',
    cancel: 'रद्द करें',
    aadharInvalid: 'कृपया 12 अंकों का सही आधार नंबर दर्ज करें (उदा. 1234 5678 9012)',
    phoneInvalid: 'कृपया 10 अंकों का सही मोबाइल नंबर दर्ज करें',
    nameRequired: 'ग्राहक का पूरा नाम दर्ज करना अनिवार्य है',

    // Blocking Red Flag Modal
    blacklistWarningTitle: 'उच्च उधार जोखिम चेतावनी!',
    blacklistWarningMessage: 'चेतावनी: इस ग्राहक का बकाया बहुत अधिक है। अधिक उधार देने से बचें।',
    blacklistWarningHindi: 'Warning: Outstanding balance high. Avoid giving further credit to this customer.',
    proceedWithCaution: 'सावधानी से आगे बढ़ें (उधार दें)',
    recordPaymentOnly: 'केवल जमा करें (पैसा लें)',
    closeWarning: 'पीछे हटें',

    // Transaction Pipeline
    recordCreditGiven: 'उधार दिया (सामान गया)',
    recordPaymentReceived: 'पैसा मिला (जमा हुआ)',
    totalBillAmount: 'कुल बिल (रुपये)',
    paidNowAmount: 'दिया गया पैसा (नकद/UPI)',
    remainingDueAmount: 'बकाया राशि (शेष उधार)',
    quickAdjustment: 'त्वरित जोड़-घटाव बटन',
    voiceDictate: 'बोलकर सामान दर्ज करें (Voice Input)',
    voiceNoteRecorder: 'ग्राहक की आवाज / ऑडियो नोट रिकॉर्ड करें',
    attachBillPhoto: 'कागजी पर्ची या डायरी का फोटो लगाएं',
    capturedPhoto: 'बिल की फोटो संलग्न है',
    recordedVoiceNote: 'ऑडियो नोट संलग्न है',
    playAudio: 'ऑडियो सुनें',
    stopAudio: 'बंद करें',
    startRecording: 'आवाज रिकॉर्ड करें',
    stopRecording: 'रिकॉर्डिंग सुरक्षित करें',
    takePhoto: 'कैमरा से फोटो खींचें',
    removePhoto: 'फोटो हटाएं',
    removeVoice: 'आवाज हटाएं',
    parsedItemsFromVoice: 'आवाज से पहचाने गए सामान:',
    transactionSavedSuccess: 'लेनदेन सफलतापूर्वक दर्ज कर लिया गया!',
    smsWhatsAppSent: 'ग्राहक को SMS व WhatsApp द्वारा रसीद भेज दी गई',
    
    // Dynamic UPI QR
    scanToPayUPI: 'बकाया भुगतान हेतु UPI QR कोड स्कैन करें',
    showHideQr: 'QR कोड दिखाएं/छिपाएं',
    qrHiddenNotice: 'सुरक्षा हेतु QR कोड छिपा हुआ है। देखने के लिए ऊपर टिक करें।',
    vpaAddress: 'दुकानदार की UPI VPA',

    // Stock Ledger
    stockLedgerTitle: 'दुकान स्टॉक बहीखाता',
    addNewProduct: 'नया सामान जोड़ें',
    productName: 'सामान का नाम',
    category: 'श्रेणी (Category)',
    unitPrice: 'मूल्य प्रति इकाई (₹)',
    unitType: 'इकाई (Unit)',
    stockCount: 'वर्तमान स्टॉक मात्रा',
    lowStockThreshold: 'कम स्टॉक चेतावनी स्तर',
    lowStockAlert: 'स्टॉक खत्म होने वाला है!',
    inStock: 'उपलब्ध',
    outOfStock: 'स्टॉक समाप्त',
    allCategories: 'सभी श्रेणियां',
    productImage: 'सामान की तस्वीर',
    voiceTag: 'ऑडियो गाइड नोट',

    // Settings, Backups & Sync
    settingsTitle: 'दुकान सेटिंग्स व क्लाउड बैकअप',
    backupCadenceTitle: 'स्वचालित बैकअप चक्र',
    weekly: 'साप्ताहिक',
    monthly: 'मासिक',
    yearly: 'वार्षिक',
    weeklyBackup: 'साप्ताहिक (Weekly)',
    monthlyBackup: 'मासिक (Monthly)',
    yearlyBackup: 'वार्षिक (Yearly)',
    cloudSyncTitle: 'क्लाउड सिंक और डेटा बैकअप',
    googleDriveSync: 'गूगल ड्राइव सिंक',
    exportPdfReport: 'खाता बही PDF डाउनलोड करें',
    downloadJson: 'JSON बैकअप डाउनलोड करें',
    restoreJson: 'JSON बैकअप रीस्टोर करें',
    googleDriveSyncTitle: 'गूगल ड्राइव डायरेक्ट बैकअप',
    googleDriveSyncDesc: 'दुकान के पूरे खाते को व्यक्तिगत गूगल ड्राइव फोल्डर में सुरक्षित रखें।',
    syncNowBtn: 'क्लाउड से अभी सिंक करें',
    syncSuccess: 'लोकल बहीखाता सुरक्षित रूप से क्लाउड में सिंक हो गया!',
    offlineModeMsg: 'ऑफ़लाइन मोड: इंटरनेट न होने पर भी काम चालू है। ऑनलाइन होते ही स्वतः सिंक होगा।',
    onlineModeMsg: 'ऑनलाइन: रियल-टाइम क्लाउड सिंक सक्रिय है।',
    generatePdfReport: 'पीडीएफ (PDF) खाता रिपोर्ट डाउनलोड करें',
    pdfReportDesc: 'तिरंगा लेआउट, दुकान की मोहर और हस्ताक्षर सहित बहुपृष्ठीय खाता बही तैयार करें।',
    runAutomatedCronBackup: 'स्वचालित क्रॉन बैकअप चलाएं',
    cronDispatchedMsg: 'स्वचालित बैकअप तैयार होकर व्यापारी के ईमेल व फोन पर भेज दिया गया!',
    merchantProfile: 'दुकानदार व्यावसायिक विवरण',
    merchantName: 'दुकानदार / प्रोपराइटर का नाम',
    merchantVpa: 'दुकान की UPI ID',
    merchantPhone: 'संपर्क मोबाइल नंबर',
    merchantAddress: 'दुकान का पूरा पता',
    
    // Calculator
    quickCalculator: 'त्वरित कैलकुलेटर',
    clearCalc: 'C',
    equals: '=',

    // General
    rupeeSymbol: '₹',
    daysElapsed: 'दिन बीत चुके हैं',
    loanDurationMsg: 'उधार लेने की तिथि: {date}। उधार लिए कुल {days} दिन बीत चुके हैं।',
    thankYouToken: 'मौर्य खाद बीज भंडार में खरीदारी के लिए आपका धन्यवाद!',
    save: 'सुरक्षित करें',
    confirm: 'पुष्टि करें',
    close: 'बंद करें',
    pwaInstall: 'ऐप इंस्टॉल करें',
    pwaInstalled: 'ऐप इंस्टॉल है',
    offlineStatus: 'ऑफ़लाइन',
    onlineStatus: 'ऑनलाइन',
    qrAppDownload: 'मोबाइल ऐप (QR)',
  },
};

type TranslationsType = typeof TRANSLATIONS.en;

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: (key: keyof TranslationsType, params?: Record<string, string | number>) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('dukan_khata_lang');
    return (saved === 'en' || saved === 'hi') ? saved : 'hi'; // Default to Hindi for Indian micro-merchants
  });

  useEffect(() => {
    localStorage.setItem('dukan_khata_lang', language);
    document.documentElement.lang = language;
  }, [language]);

  const toggleLanguage = () => {
    setLanguage(prev => (prev === 'hi' ? 'en' : 'hi'));
  };

  const t = (key: keyof TranslationsType, params?: Record<string, string | number>): string => {
    const dict = TRANSLATIONS[language] || TRANSLATIONS.en;
    let str = dict[key] || TRANSLATIONS.en[key] || String(key);
    if (params) {
      Object.entries(params).forEach(([paramKey, val]) => {
        str = str.replace(new RegExp(`\\{${paramKey}\\}`, 'g'), String(val));
      });
    }
    return str;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export function useTranslation() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
}
